# Kitticskek 🐱

Cuki cicás kártyagyűjtős játék (100 kártya, 5 ritkaság, csomagnyitás, bolt, eredmények, Cicafogó minijáték, automatikus mentés).

## Windows / számítógép (Electron)

```
npm install
npm run open      # játék indítása
npm run build     # telepítő + hordozható .exe a dist/ mappába
```

F11 = teljes képernyő.

## Android (Capacitor, APK)

```
npm install
npm run android:add      # egyszer: létrehozza az android/ projektet
npm run android:open     # szinkronizál + megnyitja Android Studióban
npm run android:apk      # vagy parancssorból: debug APK
```

Az APK helye: `android/app/build/outputs/apk/debug/app-debug.apk`

Tipp: a játék álló és fekvő módban is működik; fekvőben néz ki a legjobban.
Ha rögzíteni akarod: `android/app/src/main/AndroidManifest.xml` → az `<activity>` elembe `android:screenOrientation="sensorLandscape"`.

## Mentés
A játék a `localStorage`-ba ment (kártyák, érmék, eredmények, beállítások). Beállítások → Mentés törlése.

## GitHub Actions
Feltöltés után a `.github/workflows/build.yml` automatikusan megépíti az APK-t és a Windows .exe-t (Actions fül → futás → Artifacts).
