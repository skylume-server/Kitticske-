/* Kitticskek – játéklogika */
(function () {
  'use strict';
  const { CARDS, RARITY, RORDER, PACKS, PACK_ORDER } = window.KData;
  const TOTAL = CARDS.length;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const el = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstElementChild; };
  const fmt = (n) => Math.round(n).toLocaleString('hu-HU');
  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (a) => a[Math.floor(Math.random() * a.length)];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const byId = (id) => CARDS[id - 1];
  const icon = (n, c) => Art.icon(n, c);
  const countRar = {}; RORDER.forEach((r) => { countRar[r] = CARDS.filter((c) => c.rar === r).length; });

  /* ================= MENTÉS ================= */
  const KEY = 'kitticskek.save.v1';
  let S;
  const def = () => ({
    v: 1, coins: 300, owned: {}, packs: { basic: 2, silver: 0, gold: 0, rainbow: 0 }, ach: {}, newIds: [],
    stats: { packsOpened: 0, cardsPulled: 0, dupes: 0, earned: 0, whackBest: 0, whackPlays: 0, streak: 0, bestStreak: 0, lastDaily: '', lastFree: 0 },
    settings: { music: true, sfx: true, mvol: 0.5, svol: 0.8 }, created: Date.now(), welcomed: false,
  });
  function load() {
    const d = def();
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) { const o = JSON.parse(raw); S = Object.assign(d, o); S.stats = Object.assign(def().stats, o.stats || {}); S.settings = Object.assign(def().settings, o.settings || {}); S.packs = Object.assign(def().packs, o.packs || {}); S.owned = o.owned || {}; S.ach = o.ach || {}; S.newIds = o.newIds || []; }
      else S = d;
    } catch (e) { S = d; }
  }
  let saveT = 0;
  function saveNow() { clearTimeout(saveT); try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) { /* ignore */ } }
  function save() { clearTimeout(saveT); saveT = setTimeout(saveNow, 120); }
  addEventListener('pagehide', saveNow);
  addEventListener('beforeunload', saveNow);
  document.addEventListener('visibilitychange', () => { if (document.hidden) { saveNow(); Sound.suspend(); } else Sound.resume(); });

  const uniq = () => Object.keys(S.owned).filter((k) => S.owned[k] > 0).length;
  const rc = (r) => CARDS.filter((c) => c.rar === r && S.owned[c.id] > 0).length;

  /* ================= EFFEKTEK (részecskék) ================= */
  const FX = (() => {
    const cv = $('#fx'), cx = cv.getContext('2d');
    let W = 0, H = 0, dpr = 1, ps = [], raf = 0, last = 0;
    function size() { dpr = Math.min(2, window.devicePixelRatio || 1); W = innerWidth; H = innerHeight; cv.width = W * dpr; cv.height = H * dpr; }
    addEventListener('resize', size); size();
    function push(p) { ps.push(p); if (ps.length > 700) ps.splice(0, ps.length - 700); if (!raf) { last = performance.now(); raf = requestAnimationFrame(tick); } }
    function tick(t) {
      const dt = Math.min(40, t - last) / 16.67; last = t;
      cx.setTransform(dpr, 0, 0, dpr, 0, 0); cx.clearRect(0, 0, W, H);
      for (let i = ps.length - 1; i >= 0; i--) {
        const p = ps[i];
        p.vy += p.g * dt; p.x += p.vx * dt; p.y += p.vy * dt; p.vx *= Math.pow(p.drag, dt); p.rot += p.vr * dt; p.life -= p.decay * dt;
        if (p.life <= 0 || p.y > H + 40) { ps.splice(i, 1); continue; }
        draw(p);
      }
      if (ps.length) raf = requestAnimationFrame(tick); else { raf = 0; cx.clearRect(0, 0, W, H); }
    }
    function draw(p) {
      cx.save(); cx.translate(p.x, p.y); cx.rotate(p.rot); cx.globalAlpha = Math.max(0, Math.min(1, p.life * 1.6)); cx.fillStyle = p.c;
      const s = p.s;
      if (p.t === 'r') { cx.scale(1, Math.abs(Math.sin(p.rot * 2 + p.ph)) + 0.1); cx.fillRect(-s / 2, -s / 3, s, s * 0.6); }
      else if (p.t === 's') { cx.beginPath(); cx.moveTo(0, -s); cx.lineTo(s * 0.26, -s * 0.26); cx.lineTo(s, 0); cx.lineTo(s * 0.26, s * 0.26); cx.lineTo(0, s); cx.lineTo(-s * 0.26, s * 0.26); cx.lineTo(-s, 0); cx.lineTo(-s * 0.26, -s * 0.26); cx.closePath(); cx.fill(); }
      else if (p.t === 'h') { cx.beginPath(); cx.moveTo(0, s * 0.4); cx.bezierCurveTo(-s, -s * 0.1, -s * 0.5, -s * 0.9, 0, -s * 0.3); cx.bezierCurveTo(s * 0.5, -s * 0.9, s, -s * 0.1, 0, s * 0.4); cx.fill(); }
      else { cx.beginPath(); cx.arc(0, 0, s * 0.5, 0, 6.3); cx.fill(); cx.strokeStyle = 'rgba(160,100,0,.7)'; cx.lineWidth = 1.5; cx.stroke(); }
      cx.restore();
    }
    const COL = ['#ff8fb6', '#ffe27a', '#9ed2ff', '#b2f0d4', '#cdb2f5', '#ffffff', '#ffb066'];
    const mk = (o) => Object.assign({ x: 0, y: 0, vx: 0, vy: 0, g: 0.3, drag: 0.99, rot: rand(0, 6), vr: rand(-0.2, 0.2), s: 8, life: 1, decay: 0.012, c: '#fff', t: 'r', ph: rand(0, 6) }, o);
    return {
      confetti(x, y, n = 60, colors = COL, power = 1) { for (let i = 0; i < n; i++) { const a = rand(0, 6.283), v = rand(3, 13) * power; push(mk({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 5 * power, s: rand(6, 12), c: pick(colors), decay: rand(0.006, 0.014) })); } },
      sparkles(x, y, n = 14, colors = COL, spread = 1) { for (let i = 0; i < n; i++) { const a = rand(0, 6.283), v = rand(1, 7) * spread; push(mk({ t: 's', x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, g: 0.06, drag: 0.95, s: rand(4, 11), c: pick(colors), decay: rand(0.012, 0.03), vr: rand(-0.1, 0.1) })); } },
      hearts(x, y, n = 8) { for (let i = 0; i < n; i++) push(mk({ t: 'h', x: x + rand(-20, 20), y, vx: rand(-1.6, 1.6), vy: rand(-5, -2.5), g: -0.02, drag: 0.98, s: rand(8, 16), c: pick(['#ff7a9c', '#ff9ccf', '#ffb8d2', '#ff5fa5']), decay: rand(0.008, 0.016), vr: rand(-0.05, 0.05) })); },
      coins(x, y, n = 8) { for (let i = 0; i < n; i++) push(mk({ t: 'c', x, y, vx: rand(-5, 5), vy: rand(-11, -4), g: 0.5, s: rand(9, 14), c: '#ffd25a', decay: 0.01 })); },
      rain(ms, colors = COL) { const t0 = performance.now(); const id = setInterval(() => { for (let k = 0; k < 5; k++) push(mk({ x: rand(0, W), y: -12, vx: rand(-1.5, 1.5), vy: rand(1, 4), g: 0.1, drag: 0.995, s: rand(7, 13), c: pick(colors), decay: 0.004 })); if (performance.now() - t0 > ms) clearInterval(id); }, 55); },
    };
  })();
  const center = (e) => { const r = e.getBoundingClientRect(); return [r.left + r.width / 2, r.top + r.height / 2]; };

  /* ================= SEGÉDEK: toast, modal ================= */
  function toast(html, cls) {
    const t = el(`<div class="toast ${cls || ''}">${html}</div>`);
    $('#toasts').appendChild(t);
    setTimeout(() => t.remove(), 3200);
  }
  const modals = [];
  function modal(inner, o) {
    o = o || {};
    const back = el(`<div class="mback"><div class="modal ${o.cls || ''}">${o.close === false ? '' : `<button class="mx" aria-label="Bezár">${icon('close')}</button>`}${inner}</div></div>`);
    document.body.appendChild(back);
    const api = {
      el: back.firstElementChild, back,
      close() {
        if (!back.isConnected || back.dataset.closing) return;
        back.dataset.closing = 1; back.style.animation = 'fade .17s reverse forwards';
        setTimeout(() => back.remove(), 160);
        const i = modals.indexOf(api); if (i >= 0) modals.splice(i, 1);
        if (o.onClose) o.onClose();
      },
    };
    back.addEventListener('pointerdown', (e) => { if (e.target === back && o.close !== false) api.close(); });
    const mx = $('.mx', back); if (mx) mx.addEventListener('click', () => { Sound.play('back'); api.close(); });
    modals.push(api);
    return api;
  }
  const closeModals = () => modals.slice().forEach((m) => m.close());

  /* ================= KÁRTYA HTML ================= */
  function cardHTML(c, o) {
    o = o || {};
    const R = RARITY[c.rar];
    const num = '#' + String(c.id).padStart(3, '0');
    const ln = c.name.length > 17 ? ' xlong' : c.name.length > 11 ? ' long' : '';
    return `<div class="kcard r-${c.rar}${o.fill ? ' fill' : ''}${o.tilt ? ' tilt' : ''}" data-id="${c.id}"${o.style ? ` style="${o.style}"` : ''}><div class="kface"><div class="kin"><div class="khead"><span class="knum">${num}</span><span class="krar">${R.icon} ${R.name}</span></div><div class="kart">${Art.cardArt(c)}</div><div class="kname${ln}">${c.name}</div><div class="kstars">${'★'.repeat(R.stars)}</div></div><div class="kholo"></div><div class="kglare"></div></div>${o.badge || ''}</div>`;
  }
  function lockedHTML(c, o) {
    o = o || {};
    return `<div class="kcard locked${o.fill ? ' fill' : ''}${o.tilt ? ' tilt' : ''}" data-id="${c.id}"><div class="kface"><div class="kin"><div class="khead"><span class="knum">#${String(c.id).padStart(3, '0')}</span></div><div class="kq">?</div><div class="kname">???</div></div></div></div>`;
  }

  /* ================= ÁLLAPOT-KEZELÉS ================= */
  let hudFrozen = false, shownCoins = 0, coinTween = 0;
  function addCoins(n) { S.coins += n; if (n > 0) S.stats.earned += n; save(); if (!hudFrozen) updateHud(); }
  function updateHud(first) {
    const cp = $('#h-coins'), kp = $('#h-cards');
    if (!$('#coinv')) {
      cp.innerHTML = `${icon('coin', 'pi')}<span id="coinv">0</span><span class="plus">${icon('plus')}</span>`;
      kp.innerHTML = `<span class="pi">${icon('cards', 'pi')}</span><span id="cardv"></span><span class="plus">${icon('plus')}</span>`;
      cp.onclick = () => go('shop'); kp.onclick = () => go('collection');
      shownCoins = S.coins; $('#coinv').textContent = fmt(shownCoins);
    }
    $('#cardv').textContent = `${uniq()} / ${TOTAL}`;
    if (shownCoins !== S.coins) {
      const from = shownCoins, to = S.coins, t0 = performance.now(); cancelAnimationFrame(coinTween);
      const step = (t) => { const k = Math.min(1, (t - t0) / 600); shownCoins = from + (to - from) * (1 - Math.pow(1 - k, 3)); $('#coinv').textContent = fmt(shownCoins); if (k < 1) coinTween = requestAnimationFrame(step); else shownCoins = to; };
      coinTween = requestAnimationFrame(step);
      if (!first) { cp.classList.remove('bump'); void cp.offsetWidth; cp.classList.add('bump'); }
    }
  }

  /* ================= ERED­MÉNYEK ================= */
  const ACH = [
    { id: 'first', ico: '🐾', n: 'Első cica', d: 'Szerezd meg az első kártyádat.', g: 1, r: 25, get: uniq },
    { id: 'c10', ico: '🎀', n: 'Kezdő gyűjtő', d: 'Gyűjts 10 különböző kártyát.', g: 10, r: 50, get: uniq },
    { id: 'c25', ico: '🧸', n: 'Lelkes gyűjtő', d: 'Gyűjts 25 különböző kártyát.', g: 25, r: 100, get: uniq },
    { id: 'c50', ico: '🌸', n: 'Cicabarát', d: 'Gyűjts 50 különböző kártyát.', g: 50, r: 250, get: uniq },
    { id: 'c75', ico: '💎', n: 'Cicamester', d: 'Gyűjts 75 különböző kártyát.', g: 75, r: 400, get: uniq },
    { id: 'c100', ico: '👑', n: 'Kitticskek királynő', d: 'Gyűjtsd össze mind a 100 kártyát!', g: TOTAL, r: 1000, get: uniq },
    { id: 'p1', ico: '🎁', n: 'Első csomag', d: 'Nyiss ki egy kártyacsomagot.', g: 1, r: 20, get: () => S.stats.packsOpened },
    { id: 'p10', ico: '📦', n: 'Csomagnyitó', d: 'Nyiss ki 10 csomagot.', g: 10, r: 100, get: () => S.stats.packsOpened },
    { id: 'p50', ico: '🎊', n: 'Csomagmester', d: 'Nyiss ki 50 csomagot.', g: 50, r: 400, get: () => S.stats.packsOpened },
    { id: 'rare', ico: '🔵', n: 'Ritka lelet', d: 'Szerezz egy Rare kártyát.', g: 1, r: 40, get: () => rc('r') },
    { id: 'epic', ico: '🟣', n: 'Epikus pillanat', d: 'Szerezz egy Epic kártyát.', g: 1, r: 80, get: () => rc('e') },
    { id: 'leg', ico: '🟡', n: 'Legendás szerencse', d: 'Szerezz egy Legendary kártyát.', g: 1, r: 200, get: () => rc('l') },
    { id: 'sec', ico: '🌈', n: 'Titkok őrzője', d: 'Találj meg egy Secret kártyát.', g: 1, r: 500, get: () => rc('s') },
    { id: 'allc', ico: '🟢', n: 'Minden gyakori', d: 'Gyűjtsd össze az összes Common kártyát.', g: countRar.c, r: 150, get: () => rc('c') },
    { id: 'allr', ico: '💙', n: 'Ritkaságok ura', d: 'Gyűjtsd össze az összes Rare kártyát.', g: countRar.r, r: 300, get: () => rc('r') },
    { id: 'earn', ico: '💰', n: 'Érmegyűjtő', d: 'Szerezz összesen 1000 érmét.', g: 1000, r: 100, get: () => S.stats.earned },
    { id: 'dupe', ico: '🔁', n: 'Dupla öröm', d: 'Szerezz 20 duplikált kártyát.', g: 20, r: 80, get: () => S.stats.dupes },
    { id: 'w1', ico: '🐱', n: 'Cicafogó', d: 'Érj el 20 pontot a Cicafogóban.', g: 20, r: 50, get: () => S.stats.whackBest },
    { id: 'w2', ico: '⚡', n: 'Villámkezű', d: 'Érj el 40 pontot a Cicafogóban.', g: 40, r: 120, get: () => S.stats.whackBest },
    { id: 's3', ico: '📅', n: 'Hűséges játékos', d: 'Vedd át a napi jutalmat 3 egymást követő napon.', g: 3, r: 60, get: () => S.stats.bestStreak },
    { id: 's7', ico: '🏆', n: 'Heti bajnok', d: 'Vedd át a napi jutalmat 7 egymást követő napon.', g: 7, r: 200, get: () => S.stats.bestStreak },
  ];
  function checkAch() {
    let any = false;
    ACH.forEach((a) => {
      if (!S.ach[a.id] && a.get() >= a.g) {
        S.ach[a.id] = { u: Date.now(), c: 0 }; any = true;
        toast(`<span class="ti">${a.ico}</span><span>Új eredmény: ${a.n}!</span>`, 'ach');
        Sound.play('achieve');
      }
    });
    if (any) { save(); refreshBadges(); }
  }
  const claimable = () => ACH.filter((a) => S.ach[a.id] && !S.ach[a.id].c).length;

  /* ================= CSOMAG SORSOLÁS ================= */
  function weightedRarity(w, minIdx) {
    let tot = 0; const arr = [];
    RORDER.forEach((r, i) => { if (i >= minIdx && w[r] > 0 && countRar[r]) { arr.push([r, w[r]]); tot += w[r]; } });
    let x = Math.random() * tot;
    for (const [r, v] of arr) { x -= v; if (x <= 0) return r; }
    return arr[arr.length - 1][0];
  }
  function pickCard(r, exclude) {
    let pool = CARDS.filter((c) => c.rar === r && !exclude.has(c.id));
    if (!pool.length) pool = CARDS.filter((c) => c.rar === r);
    const wts = pool.map((c) => (S.owned[c.id] ? 1 : 3));
    let x = Math.random() * wts.reduce((a, b) => a + b, 0);
    for (let i = 0; i < pool.length; i++) { x -= wts[i]; if (x <= 0) return pool[i]; }
    return pool[pool.length - 1];
  }
  function rollPack(kind) {
    const pk = PACKS[kind], used = new Set(), out = [];
    for (let i = 0; i < pk.count; i++) { const c = pickCard(weightedRarity(pk.w, 0), used); used.add(c.id); out.push(c); }
    const minIdx = RORDER.indexOf(pk.min);
    if (!out.some((c) => RORDER.indexOf(c.rar) >= minIdx)) {
      let li = 0; out.forEach((c, i) => { if (RORDER.indexOf(c.rar) < RORDER.indexOf(out[li].rar)) li = i; });
      out[li] = pickCard(weightedRarity(pk.w, minIdx), used);
    }
    out.sort((a, b) => RORDER.indexOf(a.rar) - RORDER.indexOf(b.rar) || a.id - b.id);
    return out.map((c) => ({ c, isNew: false, refund: 0 }));
  }
  function commit(res) {
    res.forEach((r) => {
      const id = r.c.id;
      if (S.owned[id]) { r.isNew = false; r.refund = RARITY[r.c.rar].refund; S.coins += r.refund; S.stats.earned += r.refund; S.stats.dupes++; }
      else { r.isNew = true; if (!S.newIds.includes(id)) S.newIds.push(id); }
      S.owned[id] = (S.owned[id] || 0) + 1; S.stats.cardsPulled++;
    });
    S.stats.packsOpened++;
  }

  /* ================= NAVIGÁCIÓ ================= */
  const R = {};
  const TITLES = { collection: 'Kártyák', packs: 'Csomagok', shop: 'Bolt', ach: 'Eredmények', mini: 'Cicafogó' };
  let cur = 'menu', depth = 0, shopTimer = 0;
  function show(name) {
    if (cur === 'mini') stopMini();
    clearInterval(shopTimer);
    cur = name;
    $$('.screen').forEach((s) => s.classList.toggle('active', s.id === 's-' + name));
    document.body.classList.toggle('sub', name !== 'menu');
    $('#hud-title').textContent = TITLES[name] || '';
    $('#h-left').innerHTML = icon(name === 'menu' ? 'home' : 'back');
    if (R[name]) R[name]();
    if (name === 'menu') menuRefresh();
  }
  function go(name) {
    if (name === cur) { if (R[name]) R[name](); return; }
    if (name === 'menu') { if (depth > 0) { depth = 0; try { history.back(); return; } catch (e) { /* fallthrough */ } } show('menu'); return; }
    try { if (cur === 'menu') { history.pushState({ s: name }, ''); depth = 1; } else history.replaceState({ s: name }, ''); } catch (e) { /* ignore */ }
    show(name);
  }
  addEventListener('popstate', () => { closeModals(); if (!$('#open').classList.contains('on')) { depth = 0; show('menu'); } else closeOpen(); });
  function refreshScreen() { if (R[cur]) R[cur](); updateHud(); refreshBadges(); }

  /* ================= FŐMENÜ ================= */
  function logoSVG() {
    return `<svg viewBox="0 0 640 280"><defs><linearGradient id="lg1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffa6d6"/><stop offset="1" stop-color="#ff5fa5"/></linearGradient></defs>
<g stroke-linejoin="round" stroke-linecap="round"><path d="M120 190 Q96 70 112 22 Q122 12 136 22 L262 100Z" fill="#cdb8f2" stroke="#fff" stroke-width="16"/><path d="M520 190 Q544 70 528 22 Q518 12 504 22 L378 100Z" fill="#cdb8f2" stroke="#fff" stroke-width="16"/>
<path d="M140 150 Q122 80 130 50 L224 106Z" fill="#ffb8d8"/><path d="M500 150 Q518 80 510 50 L416 106Z" fill="#ffb8d8"/></g>
<g transform="translate(320 52)" stroke="#fff" stroke-width="10" stroke-linejoin="round" fill="#ff8fc6"><ellipse cx="0" cy="12" rx="26" ry="20"/><circle cx="-34" cy="-8" r="11"/><circle cx="-12" cy="-26" r="11"/><circle cx="12" cy="-26" r="11"/><circle cx="34" cy="-8" r="11"/></g>
<g transform="translate(320 52)" fill="#ff8fc6"><ellipse cx="0" cy="12" rx="26" ry="20"/><circle cx="-34" cy="-8" r="11"/><circle cx="-12" cy="-26" r="11"/><circle cx="12" cy="-26" r="11"/><circle cx="34" cy="-8" r="11"/></g>
<text x="320" y="214" text-anchor="middle" font-family="Fredoka" font-weight="700" font-size="128" textLength="580" lengthAdjust="spacingAndGlyphs" fill="#fff" stroke="#fff" stroke-width="34" stroke-linejoin="round">Kitticskek</text>
<text x="320" y="214" text-anchor="middle" font-family="Fredoka" font-weight="700" font-size="128" textLength="580" lengthAdjust="spacingAndGlyphs" fill="url(#lg1)" stroke="#d93b86" stroke-width="5" stroke-linejoin="round" paint-order="stroke">Kitticskek</text>
<text x="320" y="214" text-anchor="middle" font-family="Fredoka" font-weight="700" font-size="128" textLength="580" lengthAdjust="spacingAndGlyphs" fill="none" stroke="#fff" stroke-opacity=".45" stroke-width="3" transform="translate(-3 -5)">Kitticskek</text></svg>`;
  }
  const BUBBLES = ['Szerezz minél több Kitticske kártyát!', 'Nyiss ki egy csomagot, és találd meg a titkos cicákat! 🌈', 'Játssz a Cicafogóval, és szerezz ingyen érméket!', 'Koppints rám, és megmiauzom! 🐾', 'Csak a Titkos cicák ritkábbak a Legendásoknál!', 'A duplikátumokért érmét kapsz! 💰'];
  let bubbleI = 0, bubbleT = 0;
  function buildMenu() {
    const m = $('#s-menu');
    m.innerHTML = `<div class="stage">
      <div id="logo" title="Kitticskek">${logoSVG()}</div>
      <div id="tagline"><span class="hh">${icon('heart')}</span><span class="tt">Gyűjtsd a<br>Kitticske kártyákat!</span><span class="hh">${icon('heart')}</span></div>
      <div id="leftcol">
        <button class="sidebtn" data-go="collection"><span class="si">${icon('cards')}</span>Kártyák<span class="badge" id="b-new"></span></button>
        <button class="sidebtn" data-go="packs"><span class="si">${icon('pack')}</span>Csomagok<span class="badge" id="b-packs"></span></button>
        <button class="sidebtn" data-go="shop"><span class="si">${icon('shop')}</span>Bolt<span class="badge" id="b-shop"></span></button>
        <button class="sidebtn" data-go="ach"><span class="si">${icon('trophy')}</span>Eredmények<span class="badge" id="b-ach"></span></button>
      </div>
      <div id="chars">
        <div class="ch-pink" data-who="pink">${Art.chibi('pink')}</div>
        <div class="ch-boy" data-who="boy">${Art.chibi('boy')}</div>
        <div class="ch-brown" data-who="brown">${Art.chibi('brown')}</div>
        <div class="ch-cat" data-who="cat">${Art.mascot()}</div>
        <div id="handcard"></div>
      </div>
      <div id="bubble"></div>
      <div id="shelfpack" data-go="packs">${Art.packSVG('rainbow')}<span class="badge" id="b-shelf"></span></div>
      <button id="m-play"><span>Kártyagyűjtés</span><span class="pl">${icon('play')}</span></button>
    </div>`;
    m.addEventListener('click', (e) => {
      const g = e.target.closest('[data-go]'); if (g) { go(g.dataset.go); return; }
      if (e.target.closest('#m-play')) { go('packs'); return; }
      if (e.target.closest('#logo')) { const l = $('#logo'); l.classList.remove('hop'); void l.offsetWidth; l.classList.add('hop'); Sound.play('meow'); const [x, y] = center(l); FX.hearts(x, y + 20, 10); return; }
      if (e.target.closest('#handcard')) { const k = e.target.closest('.kcard'); if (k) openDetail(+k.dataset.id, [+k.dataset.id]); return; }
      const ch = e.target.closest('#chars > [data-who]');
      if (ch) { ch.classList.remove('jump'); void ch.offsetWidth; ch.classList.add('jump'); Sound.play(ch.dataset.who === 'cat' ? 'meow' : 'pop'); if (ch.dataset.who !== 'cat') setTimeout(() => Sound.play('meow'), 120); const [x, y] = center(ch); FX.hearts(x, y - 30, 9); FX.sparkles(x, y - 40, 8, ['#ffe27a', '#fff', '#ff9ccf']); }
    });
  }
  function menuRefresh() {
    const pool = CARDS.filter((c) => S.owned[c.id] > 0);
    const c = pool.length ? pick(pool) : CARDS[0];
    $('#handcard').innerHTML = `<div class="glow"></div>${cardHTML(c, { fill: true })}`;
    refreshBadges();
    const b = $('#bubble');
    const msgs = BUBBLES.slice();
    if (Object.values(S.packs).some((n) => n > 0)) msgs.unshift('Van nyitatlan csomagod! Koppints a Kártyagyűjtésre! 🎁');
    if (dailyAvailable()) msgs.unshift('Várnak a napi jutalmak a boltban! 🎀');
    bubbleI = 0; b.textContent = msgs[0];
    clearInterval(bubbleT);
    bubbleT = setInterval(() => { if (cur !== 'menu') return; bubbleI = (bubbleI + 1) % msgs.length; b.textContent = msgs[bubbleI]; b.classList.remove('swap'); void b.offsetWidth; b.classList.add('swap'); }, 5200);
  }
  function refreshBadges() {
    const set = (id, n) => { const e = $('#' + id); if (e) e.textContent = n > 0 ? n : ''; };
    set('b-new', S.newIds.length);
    const pk = Object.values(S.packs).reduce((a, b) => a + b, 0);
    set('b-packs', pk); set('b-shelf', pk);
    set('b-shop', dailyAvailable() ? '!' : 0);
    set('b-ach', claimable());
    updateHud();
  }

  /* ================= GYŰJTEMÉNY ================= */
  let colFilter = 'all', colMode = 'all';
  R.collection = function () {
    const root = $('#s-collection');
    const u = uniq(), pct = Math.round((u / TOTAL) * 100);
    root.innerHTML = `<div class="page"><div class="page-in">
      <div class="panel"><div class="cprog"><b>${u} / ${TOTAL}</b><div class="bar"><i style="width:${(u / TOTAL) * 100}%"></i></div><b>${pct}%</b></div>
      <div class="rstats">${RORDER.map((r) => `<span>${RARITY[r].icon} ${rc(r)}/${countRar[r]}</span>`).join('')}</div></div>
      <div class="chips" id="cf"><button class="chip ${colFilter === 'all' ? 'on' : ''}" data-f="all">Mind</button>${RORDER.map((r) => `<button class="chip ${colFilter === r ? 'on' : ''}" data-f="${r}">${RARITY[r].icon} ${RARITY[r].name} <small>${rc(r)}/${countRar[r]}</small></button>`).join('')}</div>
      <div class="chips" id="cm">${[['all', 'Összes'], ['have', 'Megvan'], ['miss', 'Hiányzik']].map(([k, n]) => `<button class="chip ${colMode === k ? 'on' : ''}" data-m="${k}">${n}</button>`).join('')}</div>
      <div class="cgrid" id="cg"></div></div></div>`;
    fillGrid();
    $('#cf').onclick = (e) => { const b = e.target.closest('[data-f]'); if (!b) return; colFilter = b.dataset.f; $$('#cf .chip').forEach((x) => x.classList.toggle('on', x === b)); fillGrid(); };
    $('#cm').onclick = (e) => { const b = e.target.closest('[data-m]'); if (!b) return; colMode = b.dataset.m; $$('#cm .chip').forEach((x) => x.classList.toggle('on', x === b)); fillGrid(); };
  };
  function filtered() { return CARDS.filter((c) => (colFilter === 'all' || c.rar === colFilter) && (colMode === 'all' || (colMode === 'have' ? S.owned[c.id] > 0 : !S.owned[c.id]))); }
  function fillGrid() {
    const list = filtered(), g = $('#cg');
    if (!list.length) { g.innerHTML = `<div class="panel" style="grid-column:1/-1;text-align:center">Itt még nincs semmi... Nyiss csomagokat! 🐾</div>`; return; }
    g.innerHTML = list.map((c, i) => {
      const n = S.owned[c.id] || 0, st = `--i:${i};animation-delay:${Math.min(i, 28) * 14}ms`;
      if (!n) return lockedHTML(c).replace('class="kcard', `style="${st}" class="kcard`);
      const badge = (S.newIds.includes(c.id) ? '<span class="knew">ÚJ!</span>' : '') + (n > 1 ? `<span class="kcnt">x${n}</span>` : '');
      return cardHTML(c, { badge, style: st, fill: true });
    }).join('');
    g.onclick = (e) => { const k = e.target.closest('.kcard'); if (!k) return; Sound.play('pop'); openDetail(+k.dataset.id, list.map((c) => c.id)); };
  }
  function attachTilt(box) {
    const face = $('.kface', box), card = $('.kcard', box);
    box.addEventListener('pointermove', (e) => {
      const r = card.getBoundingClientRect(), x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      face.style.setProperty('--ry', (x - 0.5) * 28 + 'deg'); face.style.setProperty('--rx', (0.5 - y) * 24 + 'deg');
      face.style.setProperty('--gx', x * 100 + '%'); face.style.setProperty('--gy', y * 100 + '%');
    });
    box.addEventListener('pointerleave', () => { face.style.setProperty('--rx', '0deg'); face.style.setProperty('--ry', '0deg'); });
  }
  function openDetail(id, list) {
    closeModals();
    const idx = Math.max(0, list.indexOf(id));
    const c = byId(id), n = S.owned[id] || 0, R_ = RARITY[c.rar];
    if (n && S.newIds.includes(id)) { S.newIds = S.newIds.filter((x) => x !== id); save(); refreshBadges(); }
    const info = n
      ? `<h3>${c.name}</h3><div class="rp r-${c.rar}">${R_.icon} ${R_.name} · ${R_.hu}</div><p>${c.desc}</p><div class="meta"><span>#${String(c.id).padStart(3, '0')}</span><span>Birtokolt: ${n} db</span><span>${'★'.repeat(R_.stars)}</span></div><div class="mrow" style="justify-content:flex-start"><button class="btn small" id="d-meow">Miau! 🐾</button></div>`
      : `<h3>???</h3><div class="rp" style="background:#c8bddb;box-shadow:0 .05em 0 #8f84a5">Ismeretlen ritkaság</div><p>Ez a cica még rejtőzik! Nyiss csomagokat, hogy megtaláld.</p><div class="meta"><span>#${String(c.id).padStart(3, '0')}</span></div>`;
    const m = modal(`<div class="detail"><div class="dcard">${n ? cardHTML(c, { tilt: true }) : lockedHTML(c, { tilt: true })}</div><div class="dinfo r-${c.rar}">${info}</div></div>
      ${list.length > 1 ? `<button class="navarrow" style="left:calc(var(--u)*-.3)" id="d-prev">${icon('left')}</button><button class="navarrow" style="right:calc(var(--u)*-.3)" id="d-next">${icon('right')}</button>` : ''}`, { cls: 'dmodal' });
    attachTilt($('.dcard', m.el));
    const meow = () => { Sound.play('meow'); const [x, y] = center($('.dcard', m.el)); FX.hearts(x, y, 8); };
    const dm = $('#d-meow', m.el); if (dm) dm.onclick = meow;
    const dc = $('.dcard', m.el); dc.addEventListener('click', () => { if (n) meow(); else Sound.play('deny'); });
    const nav = (d) => { Sound.play('flip'); const nid = list[(idx + d + list.length) % list.length]; openDetail(nid, list); };
    if (list.length > 1) { $('#d-prev', m.el).onclick = () => nav(-1); $('#d-next', m.el).onclick = () => nav(1); }
    if (c.rar === 'l' || c.rar === 's') { const [x, y] = center(dc); FX.sparkles(x, y, 18, ['#ffe27a', '#fff', '#ff9ccf']); }
  }

  /* ================= CSOMAGOK ================= */
  R.packs = function () {
    const root = $('#s-packs');
    const total = Object.values(S.packs).reduce((a, b) => a + b, 0);
    root.innerHTML = `<div class="page"><div class="page-in">
      <div class="panel" style="text-align:center"><div class="h2" style="justify-content:center">${icon('gift', 'hi')} ${total ? `${total} nyitatlan csomagod van!` : 'Nincs nyitatlan csomagod'}</div><div class="muted">${total ? 'Koppints egy csomagra a kinyitáshoz!' : 'Vásárolj csomagokat a boltban, vagy gyűjts érméket a Cicafogóval!'}</div></div>
      <div class="tiles">${PACK_ORDER.map((k) => { const p = PACKS[k], n = S.packs[k] || 0; return `<div class="panel ptile" data-k="${k}"><div class="cnt ${n ? '' : 'zero'}">x${n}</div><div class="psv">${Art.packSVG(k)}</div><div class="pn">${p.name}</div><div class="pd">${p.count} kártya · ${p.tag}</div><button class="btn small ${n ? '' : 'blue'}" data-act="${n ? 'open' : 'buy'}">${n ? 'Kinyitás' : 'Vásárlás'}</button></div>`; }).join('')}</div></div></div>`;
    $('.tiles', root).onclick = (e) => {
      const t = e.target.closest('.ptile'); if (!t) return; const k = t.dataset.k;
      if (S.packs[k] > 0) { Sound.play('pop'); openPack(k); } else go('shop');
    };
  };

  /* ================= BOLT ================= */
  const todayStr = (d) => { d = d || new Date(); return d.getFullYear() + '-' + (d.getMonth() + 1) + '-' + d.getDate(); };
  const yesterdayStr = () => { const d = new Date(); d.setDate(d.getDate() - 1); return todayStr(d); };
  const dailyAvailable = () => S.stats.lastDaily !== todayStr();
  const DAILY = [30, 40, 50, 60, 80, 100, 'pack'];
  const FREE_CD = 120000, FREE_AMT = 25;
  function nextStreak() { return S.stats.lastDaily === yesterdayStr() ? S.stats.streak + 1 : S.stats.lastDaily === todayStr() ? S.stats.streak : 1; }
  R.shop = function () {
    const root = $('#s-shop');
    const ns = nextStreak(), di = (ns - 1) % 7;
    root.innerHTML = `<div class="page"><div class="page-in">
      <div class="h2">${icon('pack', 'hi')} Kártyacsomagok</div>
      <div class="tiles" id="shop-tiles">${PACK_ORDER.map((k) => { const p = PACKS[k]; return `<div class="panel ptile" data-k="${k}"><div class="cnt ${S.packs[k] ? '' : 'zero'}">x${S.packs[k]}</div><div class="psv">${Art.packSVG(k)}</div><div class="pn">${p.name}</div><div class="pd">${p.count} kártya · ${p.tag}</div><button class="btn small gold" data-act="buy"><span class="price">${icon('coin')}${fmt(p.price)}</span></button></div>`; }).join('')}</div>
      <div class="h2">${icon('coin', 'hi')} Ingyen érmék</div>
      <div class="freerow">
        <div class="panel fcard" id="f-daily"><div class="fi">${icon('gift')}</div><b>Napi jutalom</b><div class="dots">${DAILY.map((_, i) => `<i class="${i < di || (i === di && !dailyAvailable()) ? 'd' : ''} ${i === di ? 't' : ''}"></i>`).join('')}</div><button class="btn small ${dailyAvailable() ? 'green' : 'gray'}" id="b-daily">${dailyAvailable() ? 'Átveszem!' : 'Holnap újra!'}</button></div>
        <div class="panel fcard" id="f-chest"><div class="fi">${icon('star')}</div><b>Csillagláda</b><div class="muted">+${FREE_AMT} érme ${FREE_CD / 60000} percenként</div><button class="btn small green" id="b-chest">...</button></div>
        <div class="panel fcard" id="f-mini"><div class="fi">${icon('paw').replace('#fff', '#ff8fc6')}</div><b>Cicafogó minijáték</b><div class="muted">Kapd el a bújócskázó cicákat!<br>Legjobb: ${S.stats.whackBest} pont</div><button class="btn small purple" id="b-mini">Játék!</button></div>
      </div>
      <div class="panel" style="margin-top:calc(var(--u)*.4);text-align:center"><div class="muted">💡 Ha duplikált kártyát találsz, érmét kapsz érte: Common 8, Rare 20, Epic 50, Legendary 120, Secret 300!</div></div>
    </div></div>`;
    $('#shop-tiles', root).onclick = (e) => { const t = e.target.closest('.ptile'); if (t) buyPack(t.dataset.k); };
    $('#b-daily', root).onclick = () => { if (dailyAvailable()) showDaily(); };
    $('#b-mini', root).onclick = () => go('mini');
    $('#b-chest', root).onclick = claimChest;
    updateChest(); clearInterval(shopTimer); shopTimer = setInterval(updateChest, 500);
  };
  function updateChest() {
    const b = $('#b-chest'); if (!b) return;
    const left = S.stats.lastFree + FREE_CD - Date.now();
    if (left <= 0) { b.textContent = 'Összegyűjtöm!'; b.disabled = false; b.className = 'btn small green'; }
    else { const s = Math.ceil(left / 1000); b.textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; b.disabled = true; b.className = 'btn small gray'; }
  }
  function claimChest() {
    if (Date.now() < S.stats.lastFree + FREE_CD) return;
    S.stats.lastFree = Date.now(); addCoins(FREE_AMT); Sound.play('coin');
    const [x, y] = center($('#b-chest')); FX.coins(x, y, 10); FX.sparkles(x, y, 12, ['#ffe27a', '#fff']);
    toast(`<span class="ti">${icon('coin')}</span><span>+${FREE_AMT} érme!</span>`); updateChest(); checkAch();
  }
  function buyPack(k) {
    const p = PACKS[k];
    if (S.coins < p.price) { Sound.play('deny'); const cp = $('#h-coins'); cp.classList.remove('shake'); void cp.offsetWidth; cp.classList.add('shake'); toast(`<span class="ti">😿</span><span>Nincs elég érméd! Játssz a Cicafogóval!</span>`); return; }
    S.coins -= p.price; S.packs[k]++; save(); updateHud(); Sound.play('coin');
    const m = modal(`<h3>Megvetted!</h3><div style="display:flex;justify-content:center"><div class="psv" style="width:calc(var(--u)*2);animation:packfloat 2s infinite">${Art.packSVG(k)}</div></div><p><b>${p.name}</b><br>${p.count} kártya vár rád!</p><div class="mrow"><button class="btn gray" id="m-later">Később</button><button class="btn green" id="m-now">Kinyitom most!</button></div>`);
    const [x, y] = center(m.el); FX.confetti(x, y, 40);
    $('#m-later', m.el).onclick = () => { m.close(); refreshScreen(); };
    $('#m-now', m.el).onclick = () => { m.close(); openPack(k); };
    if (cur === 'shop') R.shop();
  }
  function showDaily() {
    const ns = nextStreak(), di = (ns - 1) % 7;
    const m = modal(`<h3>Napi jutalom 🎀</h3><p>${ns}. napja jelentkezel egymás után!</p><div class="daily">${DAILY.map((r, i) => `<div class="dday ${i < di ? 'past' : i === di ? 'now' : ''}"><span>${i + 1}. nap</span>${r === 'pack' ? icon('pack') : icon('coin')}<span>${r === 'pack' ? 'Csomag+150' : r}</span></div>`).join('')}</div><div class="mrow"><button class="btn green big" id="m-claim">Átveszem!</button></div>`);
    $('#m-claim', m.el).onclick = () => {
      const t = todayStr(), st = nextStreak(), idx = (st - 1) % 7, rw = DAILY[idx];
      S.stats.streak = st; S.stats.bestStreak = Math.max(S.stats.bestStreak, st); S.stats.lastDaily = t;
      if (rw === 'pack') { addCoins(150); S.packs.silver++; toast(`<span class="ti">🎁</span><span>+150 érme és egy Holdfény csomag!</span>`); } else { addCoins(rw); toast(`<span class="ti">${icon('coin')}</span><span>+${rw} érme!</span>`); }
      Sound.play('coin'); const [x, y] = center(m.el); FX.confetti(x, y, 60); FX.coins(x, y, 12);
      save(); m.close(); checkAch(); refreshScreen();
    };
  }

  /* ================= ERED­MÉNYEK ================= */
  R.ach = function () {
    const root = $('#s-ach');
    const done = ACH.filter((a) => S.ach[a.id]).length;
    root.innerHTML = `<div class="page"><div class="page-in">
      <div class="panel"><div class="cprog"><b>${done} / ${ACH.length}</b><div class="bar"><i style="width:${(done / ACH.length) * 100}%"></i></div><span class="muted">teljesítve</span></div></div>
      <div class="alist" style="margin-top:calc(var(--u)*.3)">${ACH.slice().sort((a, b) => rank(a) - rank(b)).map((a) => {
    const st = S.ach[a.id], v = Math.min(a.get(), a.g), ready = st && !st.c, fin = st && st.c;
    return `<div class="panel arow ${fin ? 'done' : ''} ${ready ? 'ready' : ''}" data-id="${a.id}"><div class="aico">${a.ico}</div><div class="abody"><b>${a.n}</b><div class="ad">${a.d}</div><div class="bar"><i style="width:${(v / a.g) * 100}%"></i></div><div class="ap">${fmt(v)} / ${fmt(a.g)}</div></div><div class="aact">${ready ? `<button class="btn small gold" data-claim="${a.id}">${icon('coin', 'bi')}${a.r}</button>` : fin ? '<span style="font-size:calc(var(--u)*.6)">✅</span>' : `<span class="price">${icon('coin')}${a.r}</span>`}</div></div>`;
  }).join('')}</div></div></div>`;
    $('.alist', root).onclick = (e) => {
      const b = e.target.closest('[data-claim]'); if (!b) return;
      const a = ACH.find((x) => x.id === b.dataset.claim); if (!a || !S.ach[a.id] || S.ach[a.id].c) return;
      S.ach[a.id].c = 1; addCoins(a.r); Sound.play('coin'); const [x, y] = center(b); FX.coins(x, y, 10); FX.sparkles(x, y, 10, ['#ffe27a', '#fff']); save(); R.ach(); refreshBadges();
    };
  };
  const rank = (a) => { const s = S.ach[a.id]; return s && !s.c ? 0 : s ? 2 : 1; };

  /* ================= CSOMAGNYITÁS ================= */
  function openPack(kind) {
    if (!S.packs[kind]) return;
    S.packs[kind]--;
    const res = rollPack(kind); commit(res); saveNow();
    openSeq(kind, res);
  }
  function banner(txt, color) { const b = $('#open .o-banner'); if (!b) return; b.textContent = txt; b.style.setProperty('--bn', color); b.classList.remove('go'); void b.offsetWidth; b.classList.add('go'); }
  function ring(x, y, color) { const r = el('<div class="ring"></div>'); r.style.left = x + 'px'; r.style.top = y + 'px'; r.style.setProperty('--rg', color); document.body.appendChild(r); setTimeout(() => r.remove(), 1000); }
  function openSeq(kind, res) {
    const ov = $('#open'); hudFrozen = true;
    ov.className = 'on';
    ov.innerHTML = `<div class="o-rays"></div><div class="o-title">Koppints a csomagra!</div>
      <div class="o-packwrap" id="o-pack"><div class="pkin"><div class="pk-body">${Art.packSVG(kind)}</div><div class="pk-top">${Art.packSVG(kind)}</div></div></div>
      <div class="o-cards"></div><div class="o-banner"></div><div class="o-sum"></div><div class="o-flash"></div>
      <div class="o-actions"><button class="btn gray small" id="o-close">Mégse</button></div>`;
    const pack = $('#o-pack', ov), flips = []; let torn = false; const done = new Set();
    $('#o-close', ov).onclick = () => { Sound.play('back'); closeOpen(); };
    async function tear() {
      if (torn) return; torn = true;
      $('.o-title', ov).textContent = ''; pack.classList.add('shaking');
      Sound.play('shake'); setTimeout(() => Sound.play('shake'), 300); setTimeout(() => Sound.play('shake'), 600);
      await sleep(900);
      Sound.play('rip'); pack.classList.add('torn'); const fl = $('.o-flash', ov); fl.classList.add('go');
      const [x, y] = center(pack); FX.confetti(x, y, 90, undefined, 1.2); FX.sparkles(x, y, 30, ['#fff', '#ffe27a', '#ff9ccf', '#9ed2ff'], 1.6);
      await sleep(450); deal();
    }
    pack.addEventListener('click', tear);
    function deal() {
      pack.remove();
      $('.o-title', ov).textContent = 'Koppints a kártyákra!';
      const wrap = $('.o-cards', ov);
      wrap.innerHTML = res.map((r, i) => `<div class="flip" style="--i:${i}" data-i="${i}"><div class="flipper"><div class="fback">${Art.cardBack()}</div><div class="ffront">${cardHTML(r.c, { fill: true })}</div></div><div class="tag ${r.isNew ? 'new' : ''}">${r.isNew ? 'ÚJ!' : `${icon('coin')} +${r.refund}`}</div></div>`).join('');
      $$('.flip', wrap).forEach((f) => { flips.push(f); f.addEventListener('click', () => reveal(+f.dataset.i)); });
      $('.o-actions', ov).innerHTML = `<button class="btn purple" id="o-all">Mind felfordít</button>`;
      $('#o-all', ov).onclick = async () => { $('#o-all', ov).disabled = true; for (let i = 0; i < res.length; i++) { if (done.has(i)) continue; reveal(i); await sleep(RORDER.indexOf(res[i].c.rar) >= 3 ? 2300 : RORDER.indexOf(res[i].c.rar) >= 2 ? 1300 : 650); } };
      Sound.play('sparkle');
    }
    async function reveal(i) {
      if (done.has(i) || !torn) return; done.add(i);
      const f = flips[i], r = res[i], rar = r.c.rar;
      Sound.play('flip'); f.classList.add('on');
      await sleep(360);
      f.classList.add(rar + 'end');
      fxReveal(f, r, ov);
      if (r.isNew) setTimeout(() => Sound.play('sparkle'), 500); else setTimeout(() => Sound.play('coin'), 500);
      if (done.size === res.length) setTimeout(finish, RORDER.indexOf(rar) >= 3 ? 1800 : 800);
    }
    function finish() {
      if (!$('#open.on')) return;
      const nn = res.filter((r) => r.isNew).length, cc = res.reduce((a, r) => a + r.refund, 0);
      $('.o-sum', ov).textContent = `${nn ? `✨ ${nn} új kártya` : 'Nincs új kártya'}${cc ? `  ·  💰 +${cc} érme a duplikátumokból` : ''}`;
      const more = S.packs[kind] > 0;
      $('.o-actions', ov).innerHTML = `${more ? `<button class="btn purple" id="o-again">Még egy! (x${S.packs[kind]})</button>` : ''}<button class="btn green" id="o-done">Tovább</button>`;
      $('#o-done', ov).onclick = () => { Sound.play('click'); closeOpen(); };
      if (more) $('#o-again', ov).onclick = () => { closeOpen(true); openPack(kind); };
    }
    // billentyű: szóköz
    ov._key = (e) => { if (e.code === 'Space' || e.key === 'Enter') { if (!torn) tear(); else { const n = flips.findIndex((_, i) => !done.has(i)); if (n >= 0) reveal(n); } e.preventDefault(); } };
    document.addEventListener('keydown', ov._key);
  }
  function fxReveal(f, r, ov) {
    const [x, y] = center(f), rar = r.c.rar;
    const quake = () => { ov.classList.remove('quake'); void ov.offsetWidth; ov.classList.add('quake'); };
    if (rar === 'c') { FX.sparkles(x, y, 10, ['#fff', '#ffe27a', '#8ee8c0']); Sound.rarity('c'); }
    else if (rar === 'r') { ring(x, y, '#6cb8ff'); FX.sparkles(x, y, 22, ['#fff', '#9ed2ff', '#6cb8ff']); FX.confetti(x, y, 24, ['#9ed2ff', '#fff', '#6cb8ff'], 0.7); Sound.rarity('r'); }
    else if (rar === 'e') { ring(x, y, '#b78cff'); ov.classList.add('epic'); quake(); banner('EPIKUS!', '#8d5bea'); FX.sparkles(x, y, 36, ['#fff', '#d9c2ff', '#b78cff', '#ff9ccf'], 1.4); FX.confetti(x, y, 60, ['#b78cff', '#d9c2ff', '#fff', '#ff9ccf'], 1); Sound.rarity('e'); setTimeout(() => ov.classList.remove('epic'), 3000); }
    else if (rar === 'l') { ring(x, y, '#ffd24d'); ov.classList.add('legend'); quake(); f.classList.add('pop'); banner('LEGENDÁS!', '#d9961a'); FX.sparkles(x, y, 50, ['#fff', '#ffe27a', '#ffd24d'], 2); FX.confetti(x, y, 120, ['#ffd24d', '#ffe27a', '#fff', '#ffb066'], 1.3); FX.rain(2200, ['#ffd24d', '#ffe27a', '#fff']); Sound.rarity('l'); setTimeout(() => ov.classList.remove('legend'), 4200); }
    else { ring(x, y, '#ff8fd0'); ov.classList.add('secret'); quake(); f.classList.add('pop'); banner('TITKOS CICA!', '#c64fa3'); FX.sparkles(x, y, 70, undefined, 2.2); FX.confetti(x, y, 160, undefined, 1.5); FX.rain(3200); Sound.rarity('s'); setTimeout(() => ov.classList.remove('secret'), 5200); }
  }
  function closeOpen(keep) {
    const ov = $('#open'); document.removeEventListener('keydown', ov._key);
    ov.className = ''; ov.innerHTML = ''; hudFrozen = false;
    save(); updateHud(); checkAch(); if (!keep) refreshScreen();
  }

  /* ================= MINIJÁTÉK: CICAFOGÓ ================= */
  let mg = null;
  R.mini = function () {
    const root = $('#s-mini');
    root.innerHTML = `<div class="mgwrap"><div class="mghud"><div class="pill">⭐ <span id="mg-sc">0</span></div><div class="bar"><i id="mg-bar" style="width:100%"></i></div><div class="pill">🏅 <span id="mg-best">${S.stats.whackBest}</span></div></div>
      <div class="mgrid" id="mg-grid">${Array.from({ length: 9 }, () => '<div class="hole"><div class="pit"></div><div class="crit"></div><div class="mound"></div></div>').join('')}</div>
      <div class="combo" id="mg-combo"></div>
      <div class="panel" id="mg-intro" style="position:absolute;text-align:center;max-width:calc(var(--u)*7)"><div class="h2" style="justify-content:center">${icon('paw', 'hi').replace('#fff', '#ff8fc6')} Cicafogó</div><div class="muted" style="font-size:calc(var(--u)*.38)">Koppints a felbukkanó cicákra!<br>⭐ <b>Aranycica</b> = 5 pont<br>💤 <b>Alvó cica</b> ne ébresszed fel: −2 pont!<br>Minden pont = 1 érme.</div><div class="mrow"><button class="btn green big" id="mg-start">Kezdés!</button></div></div></div>`;
    $('#mg-start', root).onclick = startMini;
  };
  function startMini() {
    stopMini();
    $('#mg-intro').classList.add('hidden');
    const grid = $('#mg-grid'), holes = $$('.hole', grid).map((h) => ({ el: h, crit: $('.crit', h), up: false, type: 'n', tm: 0 }));
    const normals = Array.from({ length: 10 }, () => Art.catOnly(pick(CARDS)));
    const gold = Art.catOnly({ id: 200, fur: 'gold', pat: 'star:white', eyes: 'sparkle:orange', acc: 'crown:gold', opt: { mouth: 'open' } });
    const zz = Art.catOnly({ id: 201, fur: 'lilac', pat: 'none', eyes: 'sleepy', acc: 'none', opt: { mouth: 'o' } });
    const DUR = 30000;
    mg = { t0: performance.now(), dur: DUR, score: 0, combo: 0, holes, active: true, timers: [] };
    const sc = $('#mg-sc'), bar = $('#mg-bar');
    sc.textContent = 0; Sound.play('pop');
    function setUp(h, type) {
      h.type = type; h.up = true;
      h.crit.innerHTML = type === 'g' ? gold : type === 'z' ? zz : pick(normals);
      const old = $('.zz', h.el); if (old) old.remove();
      if (type === 'z') h.el.insertAdjacentHTML('beforeend', '<span class="zz">z z</span>');
      h.el.classList.add('up');
      const el_ = (performance.now() - mg.t0) / DUR;
      const stay = (type === 'g' ? 750 : 1100) - el_ * 420 + rand(-120, 120);
      h.tm = setTimeout(() => retreat(h, true), stay);
    }
    function retreat(h, missed) {
      if (!h.up) return; h.up = false; clearTimeout(h.tm); h.el.classList.remove('up', 'hit');
      if (missed && h.type === 'n') mg.combo = 0;
      const z = $('.zz', h.el); if (z) z.remove();
    }
    function spawn() {
      if (!mg || !mg.active) return;
      const free = holes.filter((h) => !h.up);
      if (free.length) { const r = Math.random(); setUp(pick(free), r < 0.1 ? 'g' : r < 0.28 ? 'z' : 'n'); }
      const k = (performance.now() - mg.t0) / DUR;
      mg.timers.push(setTimeout(spawn, Math.max(260, 720 - k * 380 + rand(-80, 120))));
    }
    holes.forEach((h) => {
      h.el.onpointerdown = (e) => {
        e.preventDefault();
        if (!mg || !mg.active || !h.up) return;
        const [x, y] = center(h.el);
        let pts = 1, txt = '+1';
        if (h.type === 'g') { pts = 5; txt = '+5'; Sound.play('gold'); FX.sparkles(x, y, 20, ['#ffe27a', '#fff']); FX.coins(x, y, 6); mg.combo++; }
        else if (h.type === 'z') { pts = -2; txt = '-2'; Sound.play('oops'); mg.combo = 0; }
        else { mg.combo++; Sound.play('hit', mg.combo); if (mg.combo % 5 === 0) { pts = 2; txt = '+2'; Sound.play('meow'); } FX.hearts(x, y, 3); }
        mg.score = Math.max(0, mg.score + pts); sc.textContent = mg.score;
        const f = el(`<div class="floatpt ${pts < 0 ? 'bad' : ''}" style="left:${x - 14}px;top:${y - 30}px">${txt}</div>`); document.body.appendChild(f); setTimeout(() => f.remove(), 800);
        const cb = $('#mg-combo'); if (mg.combo >= 3) { cb.textContent = `${mg.combo}x`; cb.classList.remove('show'); void cb.offsetWidth; cb.classList.add('show'); }
        h.el.classList.add('hit'); setTimeout(() => retreat(h, false), 90);
      };
    });
    mg.tick = setInterval(() => {
      const left = mg.dur - (performance.now() - mg.t0);
      bar.style.width = Math.max(0, (left / mg.dur) * 100) + '%';
      if (left <= 0) endMini();
    }, 100);
    spawn();
  }
  function stopMini() {
    if (!mg) return;
    mg.active = false; clearInterval(mg.tick); mg.timers.forEach(clearTimeout); mg.holes.forEach((h) => clearTimeout(h.tm)); mg = null;
  }
  function endMini() {
    const score = mg.score; stopMini();
    $$('#mg-grid .hole').forEach((h) => h.classList.remove('up'));
    const best = score > S.stats.whackBest; if (best) S.stats.whackBest = score;
    S.stats.whackPlays++;
    const bonus = best && score > 0 ? 10 : 0, coins = score + bonus;
    if (coins) addCoins(coins);
    save(); Sound.play('achieve');
    const m = modal(`<h3>Vége a játéknak!</h3><p style="font-size:calc(var(--u)*.8)">⭐ ${score} pont</p><p>${best ? '🎉 <b>Új rekord!</b> (+10 bónusz érme)' : `Rekordod: ${S.stats.whackBest}`}</p><p><span class="price" style="font-size:calc(var(--u)*.6)">${icon('coin')} +${coins}</span></p><div class="mrow"><button class="btn gray" id="mg-exit">Kész</button><button class="btn green" id="mg-again">Újra!</button></div>`, { close: false });
    const [x, y] = center(m.el); if (score >= 10) { FX.confetti(x, y, 80); FX.coins(x, y, 12); }
    $('#mg-exit', m.el).onclick = () => { m.close(); go('shop'); };
    $('#mg-again', m.el).onclick = () => { m.close(); R.mini(); startMini(); };
    checkAch(); refreshBadges();
    const b = $('#mg-best'); if (b) b.textContent = S.stats.whackBest;
  }

  /* ================= BEÁLLÍTÁSOK ================= */
  function openSettings() {
    closeModals();
    const st = S.settings;
    const m = modal(`<h3>Beállítások</h3>
      <div class="setrow"><span class="lab">${icon('music')} Háttérzene</span><button class="sw ${st.music ? 'on' : ''}" id="s-music" aria-label="Zene"></button></div>
      <div class="setrow"><span class="lab" style="opacity:.8">Hangerő</span><input type="range" id="s-mvol" min="0" max="100" value="${Math.round(st.mvol * 100)}"></div>
      <div class="setrow"><span class="lab">${icon('sound')} Hangeffektek</span><button class="sw ${st.sfx ? 'on' : ''}" id="s-sfx" aria-label="Hangeffektek"></button></div>
      <div class="setrow"><span class="lab" style="opacity:.8">Hangerő</span><input type="range" id="s-svol" min="0" max="100" value="${Math.round(st.svol * 100)}"></div>
      ${document.fullscreenEnabled ? `<div class="setrow"><span class="lab">🖥️ Teljes képernyő</span><button class="btn small blue" id="s-full">Váltás</button></div>` : ''}
      <div class="setrow"><span class="lab">🗑️ Mentés törlése</span><button class="btn small red" id="s-reset">Törlés</button></div>
      <p class="muted" style="margin-top:calc(var(--u)*.3)">Kitticskek v1.0 · ${uniq()}/${TOTAL} kártya · A játék automatikusan ment. 🐾</p>`);
    const paint = (inp) => inp.style.setProperty('--p', inp.value + '%');
    $$('input[type=range]', m.el).forEach(paint);
    $('#s-music', m.el).onclick = (e) => { st.music = !st.music; e.currentTarget.classList.toggle('on', st.music); Sound.set({ music: st.music }); if (st.music) Sound.unlock(); save(); Sound.play('click'); };
    $('#s-sfx', m.el).onclick = (e) => { st.sfx = !st.sfx; e.currentTarget.classList.toggle('on', st.sfx); Sound.set({ sfx: st.sfx }); save(); Sound.play('click'); };
    $('#s-mvol', m.el).oninput = (e) => { st.mvol = e.target.value / 100; paint(e.target); Sound.set({ mvol: st.mvol }); save(); };
    $('#s-svol', m.el).oninput = (e) => { st.svol = e.target.value / 100; paint(e.target); Sound.set({ svol: st.svol }); save(); };
    $('#s-svol', m.el).onchange = () => Sound.play('pop');
    const fs = $('#s-full', m.el); if (fs) fs.onclick = () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {}); };
    $('#s-reset', m.el).onclick = () => {
      const c = modal(`<h3>Biztos vagy benne? 😿</h3><p>Minden kártyád, érméd és eredményed törlődik!</p><div class="mrow"><button class="btn gray" id="r-no">Mégse</button><button class="btn red" id="r-yes">Igen, törlöm</button></div>`, { close: false });
      $('#r-no', c.el).onclick = () => c.close();
      $('#r-yes', c.el).onclick = () => { try { localStorage.removeItem(KEY); } catch (e) { /* ignore */ } S = def(); saveNow(); location.reload(); };
    };
  }

  /* ================= INDÍTÁS ================= */
  function buildBg() {
    const icons = ['heart', 'star', 'sparkle'];
    let fl = '';
    for (let i = 0; i < 16; i++) fl += `<span class="fl" style="left:${rand(0, 98)}%;animation-duration:${rand(10, 22)}s;animation-delay:${-rand(0, 20)}s;opacity:0">${icon(icons[i % 3])}</span>`;
    $('#bg').innerHTML = Art.menuBg() + '<div class="veil"></div><div class="floaties">' + fl + '</div>';
  }
  function init() {
    load();
    Sound.set(S.settings);
    buildBg(); buildMenu(); updateHud(true);
    $('#h-gear').innerHTML = icon('gear');
    $('#h-left').onclick = () => {
      if (cur === 'menu') { const c = $('.ch-brown'); c.classList.remove('jump'); void c.offsetWidth; c.classList.add('jump'); Sound.play('meow'); const [x, y] = center(c); FX.hearts(x, y - 40, 10); }
      else go('menu');
    };
    $('#h-gear').onclick = () => { Sound.play('click'); openSettings(); };
    document.addEventListener('pointerdown', (e) => {
      Sound.unlock();
      if (e.target.closest('.btn,.hbtn,.sidebtn,.chip,#m-play,.pill,#shelfpack')) Sound.play('click');
    }, true);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') { if (modals.length) { modals[modals.length - 1].close(); } else if ($('#open.on')) closeOpen(); else if (cur !== 'menu') go('menu'); }
    });
    try { Sound.init(); } catch (e) { /* ignore */ }
    show('menu');
    checkAch();
    setTimeout(() => {
      if (!S.welcomed) { S.welcomed = true; save(); toast(`<span class="ti">🎁</span><span>Üdv a Kitticskek világában! 2 ajándék csomag vár!</span>`); }
      else if (dailyAvailable()) showDaily();
    }, 700);
  }
  window.__kit = { get S() { return S; }, openPack, go, FX, modal, save: saveNow, ACH, checkAch, startMini };
  let started = false; const boot = () => { if (started) return; started = true; init(); };
  if (document.fonts && document.fonts.ready) { document.fonts.ready.then(boot); setTimeout(boot, 1200); } else boot();
})();
