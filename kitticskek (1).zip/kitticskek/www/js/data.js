/* Kitticskek – a 100 kártya adatai */
(function (w) {
  'use strict';

  const RARITY = {
    c: { key: 'c', name: 'Common',    hu: 'Gyakori',  icon: '🟢', color: '#6fd98a', dark: '#2f9e55', stars: 1, refund: 8,   weight: 0 },
    r: { key: 'r', name: 'Rare',      hu: 'Ritka',    icon: '🔵', color: '#6cb8ff', dark: '#2f7fd6', stars: 2, refund: 20,  weight: 0 },
    e: { key: 'e', name: 'Epic',      hu: 'Epikus',   icon: '🟣', color: '#b78cff', dark: '#7a4fd1', stars: 3, refund: 50,  weight: 0 },
    l: { key: 'l', name: 'Legendary', hu: 'Legendás', icon: '🟡', color: '#ffd24d', dark: '#d9961a', stars: 4, refund: 120, weight: 0 },
    s: { key: 's', name: 'Secret',    hu: 'Titkos',   icon: '🌈', color: '#ff8fd0', dark: '#c64fa3', stars: 5, refund: 300, weight: 0 },
  };
  const RORDER = ['c', 'r', 'e', 'l', 's'];

  const CARDS = [];
  // C(név, ritkaság, leírás, szőr, minta, szem, kiegészítők, háttér, opciók)
  function C(name, rar, desc, fur, pat, eyes, acc, bg, opt) {
    const o = {};
    (opt || '').split(',').forEach((kv) => {
      if (!kv) return;
      const [k, v] = kv.split('=');
      o[k.trim()] = v === undefined ? true : v.trim();
    });
    CARDS.push({ id: CARDS.length + 1, name, rar, desc, fur, pat, eyes, acc, bg, opt: o });
  }

  /* ---------- 🟢 COMMON (40) ---------- */
  C('Mici', 'c', 'A legkedvesebb kis kezdő cica. Imád a napsütésben szunyókálni.', 'cream', 'none', 'round:brown', 'bow:pink', 'hearts:pink:cream', 'ear=round');
  C('Cirmi', 'c', 'Narancssárga csíkos cirmos, aki mindig a konyhában lófrál.', 'orange', 'tabby:ginger', 'round:green', 'none', 'dots:peach:cream', 'mouth=open');
  C('Pamacs', 'c', 'Puha, mint egy felhő, és ugyanolyan könnyed.', 'white', 'none', 'happy', 'none', 'clouds:sky:white', 'ear=round');
  C('Mazsola', 'c', 'Éjfekete bundája alatt mazsolaédes szív dobog.', 'black', 'none', 'round:yellow', 'bell:gold', 'stars:navy:purple', '');
  C('Puszedli', 'c', 'Illatos kekszet majszol, és morzsát hagy maga után.', 'sand', 'freckle:brown', 'sleepy', 'none', 'checker:peach:cream', '');
  C('Cukorka', 'c', 'Rózsaszín bundája olyan, mint a vattacukor.', 'pink', 'spots:rose', 'sparkle:pink', 'none', 'candy:pink:lilac', '');
  C('Mályva', 'c', 'A kertben él, és virágillatot hord a bundájában.', 'lilac', 'none', 'round:purple', 'flower:pink', 'flowers:lilac:cream', 'ear=round');
  C('Barackos', 'c', 'Naplementekor pont olyan színű, mint az érett barack.', 'peach', 'none', 'happy', 'none', 'sunset:peach:yellow', '');
  C('Pihe', 'c', 'Olyan könnyű, hogy a szél is elfújná.', 'silver', 'none', 'sleepy', 'scarf:sky', 'snow:blue:white', '');
  C('Morzsa', 'c', 'Apró, de mindig talál valami finomat.', 'sand', 'freckle:brown', 'dot', 'none', 'dots:sand:cream', 'mouth=smile');
  C('Kakaó', 'c', 'Meleg kakaót kortyolgat, és dorombol hozzá.', 'choco', 'none', 'round:gold', 'scarf:cream', 'checker:brown:cream', '');
  C('Vanília', 'c', 'Édes és nyugodt, a kedvence a vaníliafagyi.', 'white', 'none', 'round:blue', 'bow:yellow', 'dots:yellow:cream', '');
  C('Citrom', 'c', 'Savanykás humorú, de mindig megnevettet.', 'yellow', 'none', 'wink', 'none', 'rays:yellow:cream', '');
  C('Málna', 'c', 'Málnaszínű kis csibész, aki imád csínytevésekkel szórakozni.', 'rose', 'none', 'happy', 'bandana:pink', 'hearts:rose:pink', '');
  C('Fahéj', 'c', 'Meleg, fűszeres illatú kandúr, aki a kandalló mellett alszik.', 'brown', 'tabby:choco', 'round:green', 'none', 'forest:peach:cream', 'ear=tuft');
  C('Kókusz', 'c', 'Fehér, mint a kókuszreszelék, és mindig kicsit álmos.', 'white', 'patch:brown', 'sleepy', 'none', 'waves:sky:cream', '');
  C('Pillangó', 'c', 'Pillangót üldöz a réten, de sosem kapja el.', 'lilac', 'none', 'sparkle:blue', 'butterfly:blue', 'flowers:mint:cream', '');
  C('Csillag', 'c', 'A homlokán csillag ragyog, ha jókedvű.', 'gray', 'star:yellow', 'round:blue', 'none', 'stars:navy:blue', '');
  C('Felhő', 'c', 'Álmodozó kiscica, aki a felhők között jár.', 'white', 'none', 'sleepy', 'none', 'clouds:blue:sky', 'ear=fold');
  C('Napocska', 'c', 'Ahol megjelenik, ott mindjárt kisüt a nap.', 'yellow', 'none', 'happy', 'none', 'rays:peach:yellow', 'mouth=open');
  C('Zsenge', 'c', 'Épp most bújt ki a fűből, fején kis hajtással.', 'mint', 'none', 'round:green', 'sprout:green', 'forest:mint:cream', '');
  C('Bodza', 'c', 'Lila bundája olyan, mint az érett bodza.', 'purple', 'none', 'round:pink', 'none', 'bubbles:lilac:pink', '');
  C('Tappancs', 'c', 'Négy nagy tappancsával mindig nyomot hagy.', 'gray', 'tux:white', 'round:yellow', 'none', 'paws:blue:sky', '');
  C('Bunda', 'c', 'Télen a legpuhább, nyáron a legálmosabb.', 'brown', 'tux:cream', 'sleepy', 'scarf:red', 'snow:sky:white', '');
  C('Szőrmók', 'c', 'Hatalmas szőrgombóc, aki mindenkit megölelne.', 'ginger', 'none', 'round:yellow', 'none', 'balloons:peach:yellow', 'ear=round,mouth=open');
  C('Tündi', 'c', 'Virágszirmok között bújócskázik.', 'mint', 'none', 'sparkle:mint', 'flower:pink', 'sakura:mint:pink', '');
  C('Gombóc', 'c', 'Kerek, mint egy gombóc, és ugyanolyan finom.', 'white', 'none', 'dot', 'none', 'bubbles:sky:cream', 'ear=round');
  C('Dömper', 'c', 'Sapkában rohangál, mindig siet valahová.', 'gray', 'tabby:silver', 'round:yellow', 'cap:red', 'stripes:sky:cream', '');
  C('Mókus', 'c', 'Makkot gyűjt a téli álomra, de mindig megeszi.', 'brown', 'none', 'round:orange', 'leaf:orange', 'forest:peach:green', 'ear=tuft');
  C('Habcsók', 'c', 'Édes, mint a habcsók, és ugyanúgy olvad a szíved.', 'white', 'none', 'happy', 'strawberry', 'cakes:pink:cream', '');
  C('Palacsinta', 'c', 'Vasárnap reggelente palacsintaillatra ébred.', 'yellow', 'none', 'sleepy', 'none', 'cakes:yellow:peach', '');
  C('Hullám', 'c', 'A tengerparton szeret szunyókálni.', 'blue', 'none', 'round:blue', 'none', 'waves:blue:sky', '');
  C('Mandula', 'c', 'Kis mandulaszemei mindent észrevesznek.', 'cream', 'patch:brown', 'round:brown', 'none', 'hearts:cream:peach', '');
  C('Zefír', 'c', 'Habkönnyű, rózsaszínes-fehér, mint a zefír.', 'pink', 'none', 'sleepy', 'bow:white', 'candy:pink:white', '');
  C('Pötty', 'c', 'Egyetlen foltja sincs ott, ahol számítanál rá.', 'white', 'spots:gray', 'round:blue', 'none', 'bubbles:mint:white', '');
  C('Cinege', 'c', 'Kék tollas barátai után ragadt rá a név.', 'blue', 'tux:cream', 'round:yellow', 'none', 'clouds:blue:cream', '');
  C('Hópehely', 'c', 'Télen született, és tavasszal sem olvad el.', 'white', 'none', 'sparkle:blue', 'none', 'snow:blue:lilac', '');
  C('Rókus', 'c', 'Róka színű, de szelíd, mint egy bárány.', 'ginger', 'tux:cream', 'round:green', 'none', 'forest:orange:cream', 'ear=big');
  C('Zsemle', 'c', 'Frissen sült, meleg és puha.', 'sand', 'none', 'wink', 'bandana:orange', 'cakes:sand:cream', '');
  C('Gesztenye', 'c', 'Ősszel gurult elő az avarból.', 'choco', 'none', 'round:orange', 'leaf:orange', 'sunset:orange:brown', '');

  /* ---------- 🔵 RARE (28) ---------- */
  C('Luna', 'r', 'Holdfényben született éjszakai cica, a csillagok a barátai.', 'black', 'moon:yellow', 'sparkle:yellow', 'none', 'moon:navy:purple', '');
  C('Szikra', 'r', 'Ha dorombol, apró villámok pattognak a bundájából.', 'yellow', 'bolt:orange', 'star:yellow', 'none', 'lights:yellow:peach', 'mouth=open');
  C('Kamilla', 'r', 'Kamillateát főz, és mindenkit megnyugtat.', 'cream', 'none', 'sparkle:green', 'flower:white', 'flowers:yellow:cream', '');
  C('Boróka', 'r', 'Az erdő mélyén él, és mindenféle titkot tud.', 'gray', 'tabby:silver', 'slit:green', 'leaf:green', 'forest:green:navy', 'ear=tuft');
  C('Tintás', 'r', 'Fekete-fehér foltos, mint a kiömlött tinta.', 'white', 'calico:black', 'round:blue', 'glasses:black', 'checker:white:lilac', '');
  C('Cuppantó', 'r', 'Puszit osztogat mindenkinek, aki elmegy mellette.', 'pink', 'none', 'heart:red', 'bow:red', 'hearts:red:pink', '');
  C('Gyöngy', 'r', 'A tenger mélyéről hozta a gyöngyét, és soha nem adja oda.', 'white', 'none', 'sparkle:pink', 'bell:pink', 'waves:lilac:pink', '');
  C('Menta', 'r', 'Zenét hallgat egész nap, ezért nem hallja, ha hívják.', 'mint', 'tux:white', 'big:mint', 'phones:pink', 'waves:mint:sky', '');
  C('Rozi hercegnő', 'r', 'Kis hercegnő, aki a palotakertben sétálgat.', 'rose', 'none', 'sparkle:pink', 'tiara:gold', 'hearts:pink:lilac', '');
  C('Sütike', 'r', 'Sütit sütni a legjobb, főleg ha cica teszi.', 'peach', 'none', 'happy', 'chef:white', 'cakes:peach:cream', '');
  C('Kalóz Kuki', 'r', 'Kincset keres a tengeren, de csak halat talál.', 'black', 'none', 'round:yellow', 'pirate:red', 'waves:navy:blue', '');
  C('Varázsló Vili', 'r', 'Varázsige helyett dorombol, de az is működik.', 'gray', 'none', 'sparkle:purple', 'wizard:purple', 'galaxy:purple:navy', '');
  C('Űrcica Zoé', 'r', 'Már a Holdon is járt, de visszajött a vacsoráért.', 'white', 'none', 'big:blue', 'antenna:pink', 'galaxy:navy:purple', '');
  C('Tengerész Tomi', 'r', 'A hajó fedélzetén szolgál, és a kormányt a mancsában tartja.', 'white', 'tux:blue', 'round:blue', 'sailor:blue', 'waves:blue:cream', '');
  C('Cukrász Csilla', 'r', 'Cukormázas mancsokkal díszíti a legszebb tortákat.', 'cream', 'none', 'sparkle:pink', 'cherries', 'cakes:pink:peach', '');
  C('Rocker Rita', 'r', 'A nagy színpadon is ő viszi a prímet.', 'black', 'none', 'round:red', 'shades:pink', 'lights:navy:pink', 'mouth=open');
  C('Mikulás Misi', 'r', 'Ajándékot oszt, és közben jóllakik süteménnyel.', 'white', 'none', 'happy', 'santa:red', 'snow:rose:cream', '');
  C('Bohóc Bubu', 'r', 'Mókás trükkökkel nevetteti meg a közönséget.', 'white', 'none', 'wink', 'party:pink', 'confetti:yellow:pink', 'mouth=open');
  C('Detektív Dani', 'r', 'Minden nyomot követ, főleg ha halszagú.', 'brown', 'tabby:choco', 'slit:gold', 'glasses:brown', 'city:sky:lilac', '');
  C('Virágos Vera', 'r', 'A réten él, és virágkoszorút fon a fejére.', 'cream', 'freckle:peach', 'sparkle:green', 'flower:yellow', 'flowers:mint:yellow', '');
  C('Gombász Gabi', 'r', 'Gombát gyűjt az erdőben, és kalapnak is használja.', 'brown', 'none', 'round:green', 'mushroom:red', 'forest:green:peach', '');
  C('Jégkrém Juli', 'r', 'Nyáron a legcukibb, mert mindig fagyiszagú.', 'pink', 'none', 'happy', 'icecream:pink', 'candy:blue:pink', '');
  C('Napszemüveges Nóra', 'r', 'Mindig kész egy kis tengerparti pihenésre.', 'orange', 'tabby:ginger', 'round:yellow', 'shades:black', 'sunset:orange:yellow', '');
  C('Cseresznye', 'r', 'Két kis cseresznyét visel a fején, és soha nem eszi meg őket.', 'rose', 'none', 'sparkle:red', 'cherries', 'dots:pink:cream', '');
  C('Eper Emma', 'r', 'Az eperföldeken él, és imádja a friss epret.', 'peach', 'freckle:red', 'sparkle:pink', 'strawberry', 'flowers:pink:mint', '');
  C('Mackó Marci', 'r', 'Medve akar lenni, de cica marad.', 'brown', 'none', 'round:brown', 'bowtie:red', 'forest:peach:green', 'ear=round');
  C('Nyuszi Nikó', 'r', 'Hosszú füleket visel, hogy kicsit nyuszi legyen.', 'white', 'none', 'happy', 'bunny:pink', 'flowers:pink:cream', '');
  C('Angyal Annus', 'r', 'Glóriával a feje fölött, bár néha csintalan.', 'white', 'none', 'sleepy', 'halo', 'clouds:yellow:cream', '');

  /* ---------- 🟣 EPIC (16) ---------- */
  C('Lángocska', 'e', 'Tűzszínű bundája melegít, a mancsa mégis hűvös marad.', 'ginger', 'flame:yellow', 'star:yellow', 'none', 'sunset:red:yellow', 'mouth=open,ear=tuft');
  C('Cseppke', 'e', 'Egy esőcseppből született, és a patakokban táncol.', 'blue', 'none', 'big:blue', 'none', 'waves:blue:mint', '');
  C('Szellő', 'e', 'Szárnyai könnyűek, mint a nyári szellő.', 'white', 'none', 'sleepy', 'wings:sky', 'clouds:sky:white', 'ear=fold');
  C('Kristály', 'e', 'Bundája kristályként csillog a fényben.', 'silver', 'star:white', 'sparkle:lilac', 'tiara:lilac', 'diamond:lilac:sky', '');
  C('Vihar', 'e', 'Morog, mint a mennydörgés, de csak ölelni szeretne.', 'gray', 'bolt:yellow', 'slit:yellow', 'none', 'lights:navy:blue', 'mouth=fang,ear=big');
  C('Tavaszka', 'e', 'Ahová lép, ott kinyílnak a virágok.', 'pink', 'none', 'heart:pink', 'flower:white+bow:mint', 'sakura:pink:white', '');
  C('Mézes Méhecske', 'e', 'Csíkos, zümmögő kis cica, a bundája mézédes.', 'yellow', 'tabby:black', 'big:brown', 'antenna:yellow', 'diamond:yellow:peach', '');
  C('Álomfogó', 'e', 'Éjjel összegyűjti a legszebb álmokat, és reggel visszaadja.', 'lilac', 'galaxy:white', 'sleepy', 'halo', 'moon:purple:navy', 'ear=fold');
  C('Szivárvány Szofi', 'e', 'Minden esőcsepp után ő hozza elő a szivárványt.', 'white', 'rainbow', 'sparkle:pink', 'bow:lilac', 'rainbow:sky:cream', '');
  C('Jégkirálynő Jázmin', 'e', 'Lehelete hópelyheket fúj, a trónja jégből van.', 'white', 'star:blue', 'sparkle:blue', 'tiara:blue', 'snow:blue:lilac', '');
  C('Sárkány Sári', 'e', 'Tüzet nem okád, de a dorombolása elég hangos.', 'green', 'spots:mint', 'slit:yellow', 'horns:yellow', 'sunset:red:orange', 'mouth=fang');
  C('Ninja Nandi', 'e', 'Hangtalanul oson, csak a csengője árulja el.', 'black', 'mask:gray', 'slit:white', 'bandana:red', 'city:purple:navy', '');
  C('Robi Robot', 'e', 'Zümmög, kattog, és mindig feltöltve alszik.', 'silver', 'bolt:blue', 'big:blue', 'antenna:blue', 'lights:navy:blue', 'mouth=smile');
  C('Tündér Tilla', 'e', 'Csillámport szór, ahogy repül az éjszakában.', 'pink', 'none', 'sparkle:pink', 'wings:lilac+tiara:pink', 'sakura:lilac:pink', '');
  C('Sellő Szilvi', 'e', 'A tenger mélyén él, és kagylókat gyűjt.', 'teal', 'spots:mint', 'sparkle:teal', 'tiara:teal', 'waves:teal:sky', '');
  C('Boszorkány Boglárka', 'e', 'Üstben főzi a legfinomabb áfonyalevest.', 'purple', 'none', 'slit:green', 'wizard:black', 'stars:purple:navy', 'mouth=open');

  /* ---------- 🟡 LEGENDARY (10) ---------- */
  C('Napkirály Leó', 'l', 'Aranyló sörénye egész országot melegít.', 'gold', 'star:orange', 'sparkle:orange', 'crown:gold', 'rays:orange:yellow', 'ear=round,mouth=open');
  C('Holdkirálynő Selene', 'l', 'Az éjszaka ura, a holdfény az ő palástja.', 'lavender', 'moon:silver', 'sparkle:purple', 'tiara:silver+wings:lavender', 'moon:navy:lilac', '');
  C('Galaxis Gábor', 'l', 'Csillagokat gyűjt a bundájába, és bejárta az egész világűrt.', 'navy', 'galaxy:white', 'star:yellow', 'wizard:navy', 'galaxy:navy:purple', 'ear=big');
  C('Arany Aranka', 'l', 'Mindent arannyá változtat, amit megérint.', 'gold', 'spots:white', 'sparkle:yellow', 'crown:pink', 'lights:gold:peach', '');
  C('Főnix Fenix', 'l', 'Lángoló pihéiből mindig újjászületik.', 'orange', 'flame:red', 'slit:yellow', 'wings:orange', 'sunset:red:yellow', 'ear=tuft');
  C('Jégherceg Jeges', 'l', 'Hideg, mint a tél, de a szíve meleg.', 'sky', 'star:white', 'sparkle:blue', 'crown:blue', 'snow:blue:white', '');
  C('Erdőkirály Tölgy', 'l', 'Az ősi erdő őrzője, a levelek az ő palástja.', 'green', 'spots:mint', 'round:gold', 'leaf:green+crown:green', 'forest:green:navy', 'ear=tuft');
  C('Tengerkirály Triton', 'l', 'A hullámok urának trónja a mélyben ragyog.', 'teal', 'spots:white', 'big:blue', 'crown:teal', 'waves:navy:teal', '');
  C('Álomkirálynő Mirabell', 'l', 'Édes álmokat szór mindenkire, aki elalszik.', 'pink', 'heart:rose', 'sparkle:pink', 'tiara:pink+wings:white', 'hearts:lilac:pink', '');
  C('Kitti, a királynő', 'l', 'A Kitticskek birodalom királynője, minden cica őt követi.', 'white', 'calico:gray', 'sparkle:blue', 'crown:pink+bow:pink', 'rainbow:pink:lilac', '');

  /* ---------- 🌈 SECRET (6) ---------- */
  C('Prizma', 's', 'Egy igazi szivárványcica, minden fényben másmilyen.', 'rainbow', 'none', 'star:pink', 'tiara:white', 'rainbow:lilac:pink', '');
  C('Árnyék Ász', 's', 'Csak éjjel bukkan fel, és a szeme csillagként ragyog.', 'void', 'galaxy:white', 'slit:yellow', 'none', 'galaxy:navy:purple', 'ear=big');
  C('Gyémánt Gizi', 's', 'Teljesen kristályból van, olyan, mint egy ékszer.', 'crystal', 'star:white', 'sparkle:blue', 'crown:white', 'diamond:sky:lilac', '');
  C('Kozmosz Kitty', 's', 'A bundájában egy egész galaxis forog.', 'cosmos', 'galaxy:white', 'star:yellow', 'halo', 'galaxy:purple:navy', '');
  C('Mimi, a hibás cica', 's', 'Néha kicsit megugrik a képe, de ettől csak még cukibb.', 'glitch', 'none', 'big:teal', 'phones:pink', 'checker:teal:pink', '');
  C('Szfinx Szandra', 's', 'Ősi aranyszobor, aki ezer éve őrzi a titkot.', 'gold', 'mask:black', 'slit:blue', 'tiara:gold+scarf:blue', 'diamond:gold:sand', 'ear=big');

  /* ---------- Csomagok ---------- */
  const PACKS = {
    basic:   { key: 'basic',   name: 'Pasztell csomag',   count: 3, price: 100,  min: 'c', w: { c: 62, r: 26, e: 9,   l: 2.6, s: 0.4 }, c1: '#ffb8d8', c2: '#ff7fb5', tag: 'Alap' },
    silver:  { key: 'silver',  name: 'Holdfény csomag',   count: 4, price: 250,  min: 'r', w: { c: 40, r: 36, e: 17,  l: 6,   s: 1 },   c1: '#b6dcff', c2: '#6fa8ff', tag: 'Ritka+' },
    gold:    { key: 'gold',    name: 'Napfény csomag',    count: 5, price: 600,  min: 'e', w: { c: 18, r: 34, e: 30,  l: 14,  s: 4 },   c1: '#ffe58a', c2: '#ffb347', tag: 'Epikus+' },
    rainbow: { key: 'rainbow', name: 'Szivárvány csomag', count: 5, price: 1400, min: 'l', w: { c: 0,  r: 10, e: 40, l: 38,  s: 12 },  c1: '#d7b8ff', c2: '#ff9ad5', tag: 'Legendás+' },
  };
  const PACK_ORDER = ['basic', 'silver', 'gold', 'rainbow'];

  w.KData = { RARITY, RORDER, CARDS, PACKS, PACK_ORDER };
})(window);
