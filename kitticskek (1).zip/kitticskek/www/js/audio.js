/* Kitticskek – szintetizált háttérzene és hangeffektek (nincs külső hangfájl) */
(function (w) {
  'use strict';
  let ctx = null, master, musicBus, sfxBus, noiseBuf;
  const S = { music: true, sfx: true, mvol: 0.5, svol: 0.8 };
  let timer = null, nextTime = 0, step = 0, started = false;

  const N = (m) => 440 * Math.pow(2, (m - 69) / 12); // MIDI -> Hz
  // C-dúr lullaby: Cmaj7 - Am7 - Fmaj7 - G6
  const CHORDS = [[48, 55, 59, 64], [45, 52, 55, 60], [41, 48, 52, 57], [43, 50, 55, 59]];
  const PENTA = [72, 74, 76, 79, 81, 84];
  const MOTIFS = [[0, 2, 4, 2, 3, 1, 2, -1], [4, 3, 2, 0, 1, 2, 3, -1], [2, 4, 5, 4, 2, 3, 1, 0], [0, -1, 2, 3, 4, -1, 3, 1]];

  function ensure() {
    if (ctx) return true;
    const AC = w.AudioContext || w.webkitAudioContext;
    if (!AC) return false;
    ctx = new AC();
    master = ctx.createGain(); master.gain.value = 0.9; master.connect(ctx.destination);
    musicBus = ctx.createGain(); musicBus.gain.value = S.mvol * 0.5; musicBus.connect(master);
    sfxBus = ctx.createGain(); sfxBus.gain.value = S.svol; sfxBus.connect(master);
    const len = ctx.sampleRate * 1.5;
    noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    return true;
  }

  function tone(freq, t, dur, type, vol, bus, opt) {
    opt = opt || {};
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.type = type || 'sine';
    o.frequency.setValueAtTime(freq, t);
    if (opt.to) o.frequency.exponentialRampToValueAtTime(opt.to, t + dur);
    if (opt.detune) o.detune.value = opt.detune;
    const a = opt.attack || 0.006;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.linearRampToValueAtTime(vol, t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g);
    let out = g;
    if (opt.filter) { const f = ctx.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = opt.filter; g.connect(f); out = f; }
    out.connect(bus || sfxBus);
    o.start(t); o.stop(t + dur + 0.05);
  }
  function noise(t, dur, vol, f0, f1, q, bus) {
    const s = ctx.createBufferSource(); s.buffer = noiseBuf;
    const f = ctx.createBiquadFilter(); f.type = 'bandpass'; f.Q.value = q || 1;
    f.frequency.setValueAtTime(f0, t); f.frequency.exponentialRampToValueAtTime(f1, t + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + dur * 0.25); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(f); f.connect(g); g.connect(bus || sfxBus);
    s.start(t); s.stop(t + dur + 0.05);
  }
  const bell = (m, t, vol, dur) => { tone(N(m), t, dur || 1.4, 'sine', vol, musicBus); tone(N(m) * 2.005, t, (dur || 1.4) * 0.5, 'sine', vol * 0.25, musicBus); };

  /* ---------- zene ---------- */
  const BEAT = 60 / 86 / 2; // nyolcadok
  function scheduleStep(t, st) {
    const bar = Math.floor(st / 8) % 4, pos = st % 8, section = Math.floor(st / 32) % 4;
    const ch = CHORDS[bar];
    if (pos === 0) {
      ch.forEach((m, i) => tone(N(m + (i ? 0 : 0)), t, BEAT * 8.2, 'sine', i === 0 ? 0.16 : 0.07, musicBus, { attack: 0.25, filter: 900 }));
      tone(N(ch[0] - 12), t, BEAT * 3.8, 'triangle', 0.2, musicBus, { filter: 400 });
    }
    if (pos === 4) tone(N(ch[0] - 12), t, BEAT * 3.6, 'triangle', 0.14, musicBus, { filter: 400 });
    // arpeggio (zenedoboz)
    const arp = [0, 1, 2, 3, 2, 1, 2, 3][pos];
    bell(ch[arp] + 24, t, 0.075, 1.0);
    // dallam
    if (section !== 0 || bar > 0) {
      const motif = MOTIFS[(section + bar) % MOTIFS.length];
      const idx = motif[pos];
      if (idx >= 0 && (pos % 2 === 0 || section > 1)) bell(PENTA[idx], t, 0.09, 1.6);
    }
    if (pos === 6 && section === 3) tone(N(PENTA[5] + 12), t, 0.3, 'triangle', 0.025, musicBus);
  }
  function pump() {
    if (!ctx) return;
    if (nextTime < ctx.currentTime - 0.2) nextTime = ctx.currentTime + 0.05;
    while (nextTime < ctx.currentTime + 0.6) {
      if (S.music) scheduleStep(nextTime, step);
      nextTime += BEAT; step++;
    }
  }
  function startMusic() {
    if (!ensure()) return;
    if (ctx.state === 'suspended') ctx.resume();
    if (timer) return;
    nextTime = ctx.currentTime + 0.1;
    timer = setInterval(pump, 150);
    started = true;
  }

  /* ---------- hangeffektek ---------- */
  const SFX = {
    click() { const t = ctx.currentTime; tone(520, t, 0.09, 'sine', 0.3, sfxBus, { to: 900 }); },
    back() { const t = ctx.currentTime; tone(700, t, 0.1, 'sine', 0.26, sfxBus, { to: 420 }); },
    pop() { const t = ctx.currentTime; tone(380, t, 0.08, 'triangle', 0.4, sfxBus, { to: 1100 }); },
    flip() { const t = ctx.currentTime; noise(t, 0.28, 0.35, 600, 3200, 1.2); tone(300, t, 0.15, 'sine', 0.12, sfxBus, { to: 600 }); },
    coin() { const t = ctx.currentTime; tone(988, t, 0.12, 'square', 0.1, sfxBus, { filter: 3000 }); tone(1319, t + 0.07, 0.35, 'square', 0.1, sfxBus, { filter: 3000 }); },
    deny() { const t = ctx.currentTime; tone(220, t, 0.14, 'square', 0.12, sfxBus, { filter: 900 }); tone(165, t + 0.1, 0.2, 'square', 0.12, sfxBus, { filter: 900 }); },
    shake() { const t = ctx.currentTime; noise(t, 0.2, 0.25, 120, 200, 2); tone(90, t, 0.18, 'triangle', 0.25, sfxBus); },
    rip() { const t = ctx.currentTime; noise(t, 0.55, 0.5, 400, 7000, 0.8); [0, 1, 2, 3, 4, 5, 6].forEach((i) => tone(N(72 + [0, 2, 4, 7, 9, 12, 16][i]), t + 0.05 + i * 0.045, 0.6, 'sine', 0.14)); },
    sparkle() { const t = ctx.currentTime; [0, 2, 4, 7].forEach((m, i) => tone(N(84 + m), t + i * 0.05, 0.4, 'sine', 0.1)); },
    meow() {
      const t = ctx.currentTime, o = ctx.createOscillator(), g = ctx.createGain(), f = ctx.createBiquadFilter(), f2 = ctx.createBiquadFilter();
      const base = 520 + Math.random() * 160;
      o.type = 'sawtooth';
      o.frequency.setValueAtTime(base * 0.85, t); o.frequency.linearRampToValueAtTime(base * 1.35, t + 0.14); o.frequency.exponentialRampToValueAtTime(base * 0.7, t + 0.42);
      f.type = 'bandpass'; f.Q.value = 3.5; f.frequency.setValueAtTime(900, t); f.frequency.linearRampToValueAtTime(2000, t + 0.15); f.frequency.linearRampToValueAtTime(1000, t + 0.42);
      f2.type = 'lowpass'; f2.frequency.value = 4200;
      g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.55, t + 0.05); g.gain.linearRampToValueAtTime(0.4, t + 0.22); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.46);
      o.connect(f); f.connect(f2); f2.connect(g); g.connect(sfxBus); o.start(t); o.stop(t + 0.5);
    },
    purr() { const t = ctx.currentTime; for (let i = 0; i < 8; i++) tone(70, t + i * 0.06, 0.07, 'sawtooth', 0.08, sfxBus, { filter: 300 }); },
    achieve() { const t = ctx.currentTime; [0, 4, 7, 12].forEach((m, i) => tone(N(72 + m), t + i * 0.1, 0.5, 'triangle', 0.18)); tone(N(84), t + 0.45, 0.9, 'sine', 0.16); },
    /* kártya-felfedés ritkaság szerint */
    r_c() { const t = ctx.currentTime; tone(N(81), t, 0.5, 'sine', 0.2); tone(N(88), t + 0.06, 0.5, 'sine', 0.1); },
    r_r() { const t = ctx.currentTime; [0, 4, 7, 12].forEach((m, i) => tone(N(76 + m), t + i * 0.07, 0.7, 'triangle', 0.18)); },
    r_e() { const t = ctx.currentTime; noise(t, 0.5, 0.2, 500, 6000, 1); [0, 3, 7, 10, 14, 19].forEach((m, i) => tone(N(69 + m), t + i * 0.07, 0.9, 'triangle', 0.18)); [0, 7, 12].forEach((m) => tone(N(57 + m), t + 0.3, 1.4, 'sine', 0.1)); },
    r_l() { const t = ctx.currentTime; noise(t, 0.9, 0.3, 300, 8000, 0.7); [0, 4, 7, 12, 16, 19, 24].forEach((m, i) => tone(N(65 + m), t + i * 0.09, 1.3, 'triangle', 0.17)); [0, 4, 7, 12].forEach((m) => tone(N(53 + m), t + 0.5, 2, 'sine', 0.13)); tone(N(96), t + 0.7, 1.4, 'sine', 0.12); },
    r_s() { const t = ctx.currentTime; noise(t, 1.4, 0.3, 200, 9000, 0.6); for (let i = 0; i < 14; i++) tone(N(60 + i * 2.2), t + i * 0.07, 1.2, 'sine', 0.13, sfxBus, { detune: i * 4 }); [0, 4, 7, 11, 14].forEach((m) => tone(N(48 + m), t + 0.9, 2.6, 'triangle', 0.1)); tone(N(100), t + 1.0, 1.6, 'sine', 0.1); },
    hit(combo) { const t = ctx.currentTime; tone(N(72 + Math.min(combo || 0, 12)), t, 0.16, 'triangle', 0.3); },
    gold() { const t = ctx.currentTime; [0, 4, 7, 12, 16].forEach((m, i) => tone(N(79 + m), t + i * 0.05, 0.4, 'triangle', 0.16)); },
    oops() { const t = ctx.currentTime; tone(300, t, 0.25, 'sawtooth', 0.14, sfxBus, { to: 120, filter: 700 }); },
    tick() { const t = ctx.currentTime; tone(1200, t, 0.04, 'square', 0.05, sfxBus, { filter: 2500 }); },
  };

  const Sound = {
    state: S,
    init() { startMusic(); },
    unlock() { if (!ensure()) return; if (ctx.state === 'suspended') ctx.resume(); if (!started) startMusic(); },
    play(name, a) {
      if (!S.sfx || !ensure()) return;
      if (ctx.state === 'suspended') ctx.resume();
      try { if (SFX[name]) SFX[name](a); } catch (e) { /* ignore */ }
    },
    rarity(r) { this.play('r_' + r); },
    set(opt) {
      Object.assign(S, opt);
      if (ctx) { musicBus.gain.setTargetAtTime(S.music ? S.mvol * 0.5 : 0, ctx.currentTime, 0.05); sfxBus.gain.setTargetAtTime(S.svol, ctx.currentTime, 0.05); }
      if (S.music && ctx) startMusic();
    },
    suspend() { if (ctx && ctx.state === 'running') ctx.suspend(); },
    resume() { if (ctx && ctx.state === 'suspended' && S.music) ctx.resume(); },
  };
  w.Sound = Sound;
})(window);
