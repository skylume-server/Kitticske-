/* Kitticskek – saját, egyedi SVG grafikák (cicák, hátterek, csomagok, ikonok, karakterek) */
(function (w) {
  'use strict';

  const IN = '#4a3552';
  const PAL = {
    white: '#ffffff', cream: '#fff0d9', sand: '#f2d7a8', peach: '#ffc9ae', orange: '#ffb066', ginger: '#f28a3d',
    yellow: '#ffe57f', gold: '#ffd25a', brown: '#b98763', choco: '#8a5a44', black: '#4b4560', gray: '#bdbfd0',
    silver: '#dce0ee', navy: '#3a3f7a', pink: '#ffb8d2', rose: '#ff8fb6', hotpink: '#ff5c9a', red: '#ff6b7a',
    lilac: '#cdb2f5', purple: '#a47be0', lavender: '#e4d4ff', blue: '#9ed2ff', sky: '#c8e8ff', teal: '#79dccf',
    mint: '#b2f0d4', green: '#86d98f',
  };
  const col = (k) => PAL[k] || k || '#ffffff';
  const h2r = (h) => { h = col(h).replace('#', ''); return [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16)); };
  const mix = (a, b, t) => { const A = h2r(a), B = h2r(b); return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * t).toString(16).padStart(2, '0')).join(''); };
  const lighten = (c, t) => mix(c, '#ffffff', t);
  const darken = (c, t) => mix(c, '#2a1830', t);
  function rng(seed) {
    let a = seed >>> 0;
    return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const parse = (s) => { const p = String(s || 'none').split(':'); return { n: p[0], c: p[1], d: p[2] }; };
  const starPath = (cx, cy, R, r, n = 5, rot = -90) => {
    let p = '';
    for (let i = 0; i < n * 2; i++) { const a = ((rot + i * 180 / n) * Math.PI) / 180; const rr = i % 2 ? r : R; p += (i ? 'L' : 'M') + (cx + Math.cos(a) * rr).toFixed(1) + ' ' + (cy + Math.sin(a) * rr).toFixed(1); }
    return p + 'Z';
  };
  const heartPath = (cx, cy, s) => `M${cx} ${cy + s * 0.9} C${cx - s * 1.6} ${cy - s * 0.2} ${cx - s * 0.9} ${cy - s * 1.2} ${cx} ${cy - s * 0.4} C${cx + s * 0.9} ${cy - s * 1.2} ${cx + s * 1.6} ${cy - s * 0.2} ${cx} ${cy + s * 0.9}Z`;
  const SW = `stroke="${IN}" stroke-width="3.2" stroke-linejoin="round" stroke-linecap="round"`;
  const SW2 = `stroke="${IN}" stroke-width="2.4" stroke-linejoin="round" stroke-linecap="round"`;

  /* ================= HÁTTEREK ================= */
  function cloud(cx, cy, s, op = 0.9) {
    return `<g opacity="${op}" fill="#fff"><circle cx="${cx - 12 * s}" cy="${cy}" r="${10 * s}"/><circle cx="${cx}" cy="${cy - 6 * s}" r="${13 * s}"/><circle cx="${cx + 14 * s}" cy="${cy}" r="${10 * s}"/><rect x="${cx - 22 * s}" y="${cy}" width="${44 * s}" height="${10 * s}" rx="${5 * s}"/></g>`;
  }
  function bgMarkup(bg, U, rnd) {
    const [d, a, b] = String(bg || 'dots:pink:cream').split(':');
    const A = col(a), B = col(b);
    const R = (lo, hi) => lo + rnd() * (hi - lo);
    let s = `<defs><linearGradient id="bg${U}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${A}"/><stop offset="1" stop-color="${B}"/></linearGradient></defs><rect width="200" height="200" fill="url(#bg${U})"/>`;
    switch (d) {
      case 'dots': for (let i = 0; i < 18; i++) s += `<circle cx="${R(0, 200)}" cy="${R(0, 200)}" r="${R(3, 11)}" fill="#fff" opacity="${R(0.25, 0.55)}"/>`; break;
      case 'stars': for (let i = 0; i < 16; i++) { const r = R(3, 8); s += `<path d="${starPath(R(5, 195), R(5, 195), r, r * 0.45)}" fill="${i % 3 ? '#fff' : '#ffe27a'}" opacity="${R(0.5, 0.95)}"/>`; } break;
      case 'hearts': for (let i = 0; i < 14; i++) s += `<path d="${heartPath(R(8, 192), R(8, 192), R(3, 8))}" fill="#fff" opacity="${R(0.35, 0.7)}"/>`; break;
      case 'clouds': s += cloud(45, 50, 1.4) + cloud(155, 90, 1.1, 0.8) + cloud(60, 150, 1.2, 0.7) + cloud(170, 30, 0.8, 0.7); break;
      case 'rays': for (let i = 0; i < 16; i++) { const a0 = (i * 22.5 * Math.PI) / 180, a1 = ((i * 22.5 + 11.25) * Math.PI) / 180; s += `<path d="M100 110 L${100 + Math.cos(a0) * 220} ${110 + Math.sin(a0) * 220} L${100 + Math.cos(a1) * 220} ${110 + Math.sin(a1) * 220}Z" fill="#fff" opacity=".22"/>`; } break;
      case 'stripes': for (let i = -2; i < 8; i++) s += `<polygon points="${i * 40},0 ${i * 40 + 20},0 ${i * 40 + 220},200 ${i * 40 + 200},200" fill="#fff" opacity=".22"/>`; break;
      case 'bubbles': for (let i = 0; i < 12; i++) { const r = R(6, 20), x = R(8, 192), y = R(8, 192); s += `<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" opacity=".18" stroke="#fff" stroke-opacity=".6" stroke-width="1.6"/><circle cx="${x - r * 0.35}" cy="${y - r * 0.35}" r="${r * 0.2}" fill="#fff" opacity=".8"/>`; } break;
      case 'flowers': for (let i = 0; i < 9; i++) { const x = R(12, 188), y = R(12, 188), r = R(5, 9); let f = ''; for (let k = 0; k < 5; k++) { const an = (k * 72 * Math.PI) / 180; f += `<circle cx="${x + Math.cos(an) * r}" cy="${y + Math.sin(an) * r}" r="${r * 0.7}"/>`; } s += `<g fill="${i % 2 ? '#fff' : '#ffd6ea'}" opacity=".85">${f}</g><circle cx="${x}" cy="${y}" r="${r * 0.55}" fill="#ffd95e"/>`; } break;
      case 'snow': for (let i = 0; i < 20; i++) s += `<circle cx="${R(0, 200)}" cy="${R(0, 200)}" r="${R(1.5, 4.5)}" fill="#fff" opacity=".85"/>`; for (let i = 0; i < 6; i++) { const x = R(10, 190), y = R(10, 190), r = R(6, 10); s += `<g stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".85"><path d="M${x - r} ${y}H${x + r}M${x} ${y - r}V${y + r}M${x - r * 0.7} ${y - r * 0.7}L${x + r * 0.7} ${y + r * 0.7}M${x + r * 0.7} ${y - r * 0.7}L${x - r * 0.7} ${y + r * 0.7}"/></g>`; } break;
      case 'checker': for (let y = 0; y < 8; y++) for (let x = 0; x < 8; x++) if ((x + y) % 2) s += `<rect x="${x * 25}" y="${y * 25}" width="25" height="25" fill="#fff" opacity=".22"/>`; break;
      case 'waves': for (let k = 0; k < 4; k++) { const y = 120 + k * 22; s += `<path d="M0 ${y} Q25 ${y - 14} 50 ${y} T100 ${y} T150 ${y} T200 ${y} V200 H0Z" fill="#fff" opacity="${0.16 + k * 0.05}"/>`; } for (let i = 0; i < 6; i++) s += `<path d="${starPath(R(10, 190), R(10, 100), 4, 1.8, 4)}" fill="#fff" opacity=".8"/>`; break;
      case 'confetti': for (let i = 0; i < 26; i++) s += `<rect x="${R(0, 195)}" y="${R(0, 195)}" width="${R(4, 9)}" height="${R(3, 6)}" rx="1.5" fill="${['#ff8fb6', '#ffe27a', '#9ed2ff', '#b2f0d4', '#cdb2f5'][i % 5]}" transform="rotate(${R(0, 180)} ${R(0, 200)} ${R(0, 200)})" opacity=".9"/>`; break;
      case 'moon': s += `<circle cx="150" cy="48" r="26" fill="#fff6c8"/><circle cx="160" cy="40" r="23" fill="${A}"/>`; for (let i = 0; i < 14; i++) s += `<path d="${starPath(R(5, 195), R(5, 150), R(2, 5), 1.2, 4)}" fill="#fff" opacity="${R(0.5, 1)}"/>`; break;
      case 'rainbow': { const cl = ['#ff7a8a', '#ffb066', '#ffe57f', '#86d98f', '#9ed2ff', '#b79cff']; cl.forEach((c, i) => { s += `<path d="M${100 - (150 - i * 11)} 175 A${150 - i * 11} ${150 - i * 11} 0 0 1 ${100 + (150 - i * 11)} 175" fill="none" stroke="${c}" stroke-width="11" opacity=".75"/>`; }); s += cloud(30, 170, 1.5) + cloud(172, 168, 1.4); break; }
      case 'galaxy': s += `<rect width="200" height="200" fill="url(#bg${U})"/>`; for (let i = 0; i < 4; i++) s += `<circle cx="${R(20, 180)}" cy="${R(20, 180)}" r="${R(30, 60)}" fill="${['#ff7ad9', '#7a8cff', '#b45cff', '#4fd1ff'][i]}" opacity=".16"/>`; for (let i = 0; i < 60; i++) s += `<circle cx="${R(0, 200)}" cy="${R(0, 200)}" r="${R(0.6, 2)}" fill="#fff" opacity="${R(0.4, 1)}"/>`; for (let i = 0; i < 5; i++) s += `<path d="${starPath(R(10, 190), R(10, 190), R(4, 7), 1.6, 4)}" fill="#fff6c8"/>`; break;
      case 'sakura': for (let i = 0; i < 18; i++) { const x = R(0, 200), y = R(0, 200); s += `<ellipse cx="${x}" cy="${y}" rx="${R(3, 6)}" ry="${R(2, 4)}" fill="${i % 2 ? '#fff' : '#ffc4dc'}" opacity=".9" transform="rotate(${R(0, 180)} ${x} ${y})"/>`; } break;
      case 'candy': for (let i = 0; i < 7; i++) { const x = R(15, 185), y = R(15, 185), r = R(8, 13); s += `<g transform="rotate(${R(-30, 30)} ${x} ${y})"><path d="M${x - r - 8} ${y - 6} L${x - r + 1} ${y} L${x - r - 8} ${y + 6}ZM${x + r + 8} ${y - 6} L${x + r - 1} ${y} L${x + r + 8} ${y + 6}Z" fill="#fff" opacity=".85"/><circle cx="${x}" cy="${y}" r="${r}" fill="${['#ff8fb6', '#fff', '#b79cff', '#9ed2ff'][i % 4]}" opacity=".9"/><path d="M${x - r * 0.7} ${y - r * 0.7} Q${x} ${y} ${x + r * 0.7} ${y - r * 0.7}M${x - r} ${y} Q${x} ${y + r * 0.4} ${x + r} ${y}" stroke="#fff" stroke-width="2.4" fill="none" opacity=".8"/></g>`; } break;
      case 'sunset': s += `<circle cx="100" cy="130" r="42" fill="#fff4b0" opacity=".9"/>`; for (let i = 0; i < 5; i++) s += `<rect x="0" y="${118 + i * 14}" width="200" height="${5 + i}" fill="${A}" opacity=".5"/>`; s += cloud(40, 50, 1.2, 0.7) + cloud(160, 70, 1.0, 0.6); s += `<rect x="0" y="170" width="200" height="30" fill="${darken(B, 0.2)}" opacity=".35"/>`; break;
      case 'city': { s += `<circle cx="150" cy="44" r="14" fill="#fff" opacity=".7"/>`; let x = -5; const dk = darken(B, 0.35); while (x < 200) { const wd = R(18, 34), h = R(40, 100); s += `<rect x="${x}" y="${200 - h}" width="${wd}" height="${h}" fill="${dk}" opacity=".85"/>`; for (let yy = 200 - h + 6; yy < 192; yy += 9) for (let xx = x + 4; xx < x + wd - 5; xx += 8) if (rnd() > 0.45) s += `<rect x="${xx}" y="${yy}" width="4" height="5" fill="#ffe9a0"/>`; x += wd + 2; } break; }
      case 'forest': for (let k = 0; k < 2; k++) { const dk = darken(B, 0.25 + k * 0.15); for (let x = -10 + k * 14; x < 210; x += 34) { const h = R(60, 100) - k * 15; s += `<path d="M${x} 205 L${x + 18} ${200 - h} L${x + 36} 205Z" fill="${dk}" opacity="${0.8 - k * 0.1}"/>`; } } for (let i = 0; i < 12; i++) s += `<circle cx="${R(5, 195)}" cy="${R(30, 170)}" r="${R(1.4, 2.8)}" fill="#fff6a0" opacity=".9"/>`; break;
      case 'cakes': for (let i = 0; i < 7; i++) { const x = R(15, 185), y = R(15, 185), c = ['#ffb8d2', '#fff0d9', '#c8e8ff', '#ffe57f'][i % 4]; s += `<g opacity=".85"><path d="M${x - 9} ${y} L${x - 6} ${y + 14} H${x + 6} L${x + 9} ${y}Z" fill="#fff"/><ellipse cx="${x}" cy="${y - 1}" rx="10" ry="6" fill="${c}"/><ellipse cx="${x}" cy="${y - 7}" rx="7" ry="5" fill="${c}"/><circle cx="${x}" cy="${y - 13}" r="2.6" fill="#ff5c7a"/></g>`; } break;
      case 'paws': for (let i = 0; i < 12; i++) { const x = R(10, 190), y = R(10, 190), r = R(5, 9); s += `<g fill="#fff" opacity=".4" transform="rotate(${R(-40, 40)} ${x} ${y})"><ellipse cx="${x}" cy="${y + r * 0.4}" rx="${r}" ry="${r * 0.8}"/><circle cx="${x - r * 1.1}" cy="${y - r * 0.6}" r="${r * 0.38}"/><circle cx="${x - r * 0.4}" cy="${y - r * 1.2}" r="${r * 0.38}"/><circle cx="${x + r * 0.4}" cy="${y - r * 1.2}" r="${r * 0.38}"/><circle cx="${x + r * 1.1}" cy="${y - r * 0.6}" r="${r * 0.38}"/></g>`; } break;
      case 'diamond': for (let y = -1; y < 6; y++) for (let x = -1; x < 6; x++) s += `<path d="M${x * 40 + 20} ${y * 40} L${x * 40 + 40} ${y * 40 + 20} L${x * 40 + 20} ${y * 40 + 40} L${x * 40} ${y * 40 + 20}Z" fill="${(x + y) % 2 ? '#fff' : 'none'}" opacity=".22" stroke="#fff" stroke-opacity=".35" stroke-width="1.5"/>`; break;
      case 'lights': for (let i = 0; i < 18; i++) { const r = R(5, 20); s += `<circle cx="${R(0, 200)}" cy="${R(0, 200)}" r="${r}" fill="#fff" opacity="${R(0.1, 0.35)}"/>`; } break;
      case 'balloons': for (let i = 0; i < 5; i++) { const x = 20 + i * 40 + R(-8, 8), y = R(30, 90), c = ['#ff8fb6', '#9ed2ff', '#ffe57f', '#b79cff', '#b2f0d4'][i]; s += `<path d="M${x} ${y + 20} Q${x + 8} ${y + 70} ${x - 4} ${y + 120}" stroke="#fff" stroke-width="1.5" fill="none" opacity=".8"/><ellipse cx="${x}" cy="${y}" rx="15" ry="19" fill="${c}" opacity=".9"/><ellipse cx="${x - 5}" cy="${y - 7}" rx="3.5" ry="6" fill="#fff" opacity=".6"/>`; } break;
      default: break;
    }
    return s;
  }

  /* ================= CICA ================= */
  const SPECIAL = { rainbow: '#ffffff', void: '#8f6fd0', crystal: '#e8f6ff', cosmos: '#a98cf0', glitch: '#ffffff', gold: '#ffe27a' };

  function furDefs(f, U) {
    const g = (stops, rad) => {
      const st = stops.map((c, i) => `<stop offset="${(i / (stops.length - 1)).toFixed(2)}" stop-color="${c}"/>`).join('');
      return rad ? `<radialGradient id="fur${U}" cx=".4" cy=".35" r=".8">${st}</radialGradient>` : `<linearGradient id="fur${U}" x1="0" y1="0" x2="1" y2="1">${st}</linearGradient>`;
    };
    switch (f) {
      case 'rainbow': return g(['#ffb3d9', '#ffe2a0', '#b9f5c8', '#a9dcff', '#d4b5ff']);
      case 'void': return g(['#6b4aae', '#35205e', '#1a0f33'], true);
      case 'crystal': return g(['#f6fdff', '#bfe6ff', '#e6d6ff']);
      case 'cosmos': return g(['#9a6df0', '#5a35b0', '#2e1f6b'], true);
      case 'glitch': return g(['#ffffff', '#e8f8ff']);
      case 'gold': return g(['#fff4b8', '#ffd25a', '#e0a02c']);
      default: return '';
    }
  }

  function earMarkup(type, fill, inner, tuft) {
    let L;
    switch (type) {
      case 'round': L = `<ellipse cx="52" cy="62" rx="21" ry="20" fill="${fill}" ${SW}/><ellipse cx="52" cy="63" rx="11" ry="10.5" fill="${inner}"/>`; break;
      case 'fold': L = `<path d="M34 98 Q26 58 52 54 Q78 54 92 74 Z" fill="${fill}" ${SW}/><path d="M42 90 Q40 68 54 65 Q68 65 80 76Z" fill="${inner}"/>`; break;
      case 'big': L = `<path d="M38 94 Q18 34 34 12 Q42 8 50 14 L98 58 Z" fill="${fill}" ${SW}/><path d="M46 82 Q34 42 42 26 L84 60Z" fill="${inner}"/>`; break;
      case 'tuft': L = `<path d="M40 92 Q26 44 42 28 Q48 24 54 28 L94 60 Z" fill="${fill}" ${SW}/><path d="M48 80 Q40 50 47 40 L80 62Z" fill="${inner}"/><path d="M42 28 L38 13 M47 26 L48 9 M53 29 L62 15" stroke="${tuft}" stroke-width="3.2" stroke-linecap="round" fill="none"/>`; break;
      default: L = `<path d="M40 92 Q28 42 44 30 Q50 26 56 30 L94 60 Z" fill="${fill}" ${SW}/><path d="M48 80 Q40 50 48 42 L80 62Z" fill="${inner}"/>`;
    }
    return L + `<g transform="translate(200 0) scale(-1 1)">${L}</g>`;
  }

  function eyeMarkup(type, c, side) {
    const I = IN;
    switch (type) {
      case 'happy': return `<path d="M-10 4 Q0 -10 10 4" fill="none" stroke="${I}" stroke-width="4.4" stroke-linecap="round"/>`;
      case 'sleepy': return `<path d="M-10 -2 Q0 9 10 -2" fill="none" stroke="${I}" stroke-width="4.2" stroke-linecap="round"/><path d="M-10 -2 L-13 -5 M10 -2 L13 -5" stroke="${I}" stroke-width="2.4" stroke-linecap="round"/>`;
      case 'dot': return `<circle r="5.6" fill="${I}"/><circle cx="-1.8" cy="-2" r="2" fill="#fff"/>`;
      case 'star': return `<path d="${starPath(0, 1, 13, 6)}" fill="${col(c || 'yellow')}" stroke="${I}" stroke-width="2.4" stroke-linejoin="round"/><circle cx="-2" cy="-2" r="1.8" fill="#fff"/>`;
      case 'heart': return `<path d="${heartPath(0, 0, 8.5)}" fill="${col(c || 'red')}" stroke="${I}" stroke-width="2.4" stroke-linejoin="round"/><ellipse cx="-3.6" cy="-3.6" rx="2" ry="1.4" fill="#fff" transform="rotate(-30 -3.6 -3.6)"/>`;
      case 'slit': { const ic = col(c || 'yellow'); return `<ellipse rx="10" ry="11.5" fill="${ic}" stroke="${I}" stroke-width="2.4"/><ellipse rx="2.8" ry="10" fill="${I}"/><circle cx="-3.4" cy="-4.4" r="2.4" fill="#fff"/>`; }
      case 'big': { const ic = col(c || 'blue'); return `<ellipse rx="12" ry="14" fill="${I}"/><ellipse rx="10.2" ry="12.4" fill="${ic}"/><ellipse cx="0" cy="3" rx="10" ry="8" fill="${darken(ic, 0.18)}" opacity=".55"/><ellipse rx="6" ry="8.4" fill="${I}"/><circle cx="-3.8" cy="-5.2" r="4.2" fill="#fff"/><circle cx="4" cy="5" r="2.2" fill="#fff" opacity=".9"/><path d="M-11 -9 L-15 -13 M11 -9 L15 -13" stroke="${I}" stroke-width="2.4" stroke-linecap="round"/>`; }
      case 'sparkle': { const ic = col(c || 'blue'); return `<ellipse rx="11" ry="13" fill="${I}"/><ellipse rx="9.6" ry="11.8" fill="${ic}"/><ellipse cx="0" cy="3" rx="9.4" ry="7.6" fill="${darken(ic, 0.15)}" opacity=".5"/><ellipse rx="5.4" ry="7.6" fill="${I}"/><path d="${starPath(-3.4, -4.4, 5.2, 1.6, 4)}" fill="#fff"/><path d="${starPath(4, 5, 2.8, 0.9, 4)}" fill="#fff"/>`; }
      default: { const ic = c ? col(c) : null; return ic ? `<ellipse rx="9.6" ry="11.6" fill="${I}"/><ellipse rx="8.4" ry="10.4" fill="${ic}"/><ellipse rx="5" ry="7.4" fill="${I}"/><circle cx="-3.2" cy="-4" r="3.2" fill="#fff"/><circle cx="3" cy="4" r="1.6" fill="#fff" opacity=".9"/>` : `<ellipse rx="8.4" ry="10.4" fill="${I}"/><circle cx="-2.8" cy="-3.6" r="3.2" fill="#fff"/><circle cx="3" cy="4" r="1.6" fill="#fff" opacity=".9"/>`; }
    }
  }

  function mouthMarkup(t) {
    const base = `<path d="M100 134 Q100 140 93 141 M100 134 Q100 140 107 141" fill="none" stroke="${IN}" stroke-width="2.8" stroke-linecap="round"/>`;
    switch (t) {
      case 'open': return `<path d="M89 136 Q100 160 111 136 Z" fill="#7a2f4d" stroke="${IN}" stroke-width="2.8" stroke-linejoin="round"/><path d="M93 148 Q100 142 107 148 Q100 156 93 148Z" fill="#ff8fa8"/>`;
      case 'smile': return `<path d="M90 137 Q100 148 110 137" fill="none" stroke="${IN}" stroke-width="2.8" stroke-linecap="round"/>`;
      case 'o': return `<ellipse cx="100" cy="143" rx="4.6" ry="5.4" fill="#7a2f4d" stroke="${IN}" stroke-width="2.4"/>`;
      case 'fang': return base + `<path d="M91 140 L94 148 L97 141Z M109 140 L106 148 L103 141Z" fill="#fff" stroke="${IN}" stroke-width="1.6" stroke-linejoin="round"/>`;
      case 'tongue': return base + `<path d="M96 142 Q100 154 104 142Z" fill="#ff8fa8" stroke="${IN}" stroke-width="2" stroke-linejoin="round"/>`;
      default: return base;
    }
  }

  function patMarkup(p, base, U, rnd, fur) {
    const c = p.c ? col(p.c) : '#fff';
    const R = (lo, hi) => lo + rnd() * (hi - lo);
    switch (p.n) {
      case 'tabby': return `<g stroke="${c}" stroke-width="5.4" stroke-linecap="round" fill="none"><path d="M92 58 L93 80"/><path d="M100 56 L100 84"/><path d="M108 58 L107 80"/><path d="M34 112 L54 114 M36 122 L52 122 M166 112 L146 114 M164 122 L148 122"/></g>`;
      case 'tux': return `<ellipse cx="100" cy="150" rx="54" ry="38" fill="${c}"/><ellipse cx="100" cy="92" rx="10" ry="30" fill="${c}"/>`;
      case 'siam': return `<radialGradient id="sm${U}"><stop offset="0" stop-color="${c}" stop-opacity=".95"/><stop offset=".7" stop-color="${c}" stop-opacity=".55"/><stop offset="1" stop-color="${c}" stop-opacity="0"/></radialGradient><ellipse cx="100" cy="124" rx="46" ry="36" fill="url(#sm${U})"/>`;
      case 'calico': { const c2 = c === col('black') ? col('ginger') : lighten(c, 0.3); return `<ellipse cx="62" cy="80" rx="26" ry="22" fill="${c}"/><ellipse cx="146" cy="92" rx="20" ry="24" fill="${c2}"/><ellipse cx="120" cy="64" rx="14" ry="10" fill="${c}"/>`; }
      case 'patch': return `<ellipse cx="72" cy="108" rx="22" ry="20" fill="${c}"/><ellipse cx="50" cy="76" rx="14" ry="12" fill="${c}"/>`;
      case 'cap': return `<ellipse cx="100" cy="64" rx="56" ry="24" fill="${c}"/>`;
      case 'spots': { let s = ''; for (let i = 0; i < 8; i++) s += `<circle cx="${R(45, 155)}" cy="${R(66, 150)}" r="${R(4, 9)}" fill="${c}" opacity=".9"/>`; return s; }
      case 'star': return `<path d="${starPath(100, 80, 11, 5)}" fill="${c}" stroke="${darken(c, 0.2)}" stroke-width="1.6" stroke-linejoin="round"/>`;
      case 'heart': return `<path d="${heartPath(100, 80, 8)}" fill="${c}" stroke="${darken(c, 0.2)}" stroke-width="1.6" stroke-linejoin="round"/>`;
      case 'mask': return `<path d="M36 104 Q70 92 100 104 Q130 92 164 104 Q168 128 140 130 Q116 130 100 118 Q84 130 60 130 Q32 128 36 104Z" fill="${c}" opacity=".95"/>`;
      case 'half': return `<rect x="30" y="50" width="70" height="125" fill="${c}"/>`;
      case 'freckle': { let s = ''; [[52, 126], [58, 132], [46, 133], [148, 126], [142, 132], [154, 133]].forEach(([x, y]) => { s += `<circle cx="${x}" cy="${y}" r="1.9" fill="${c}"/>`; }); return s; }
      case 'bolt': return `<path d="M106 58 L90 86 L101 86 L94 106 L114 76 L103 76Z" fill="${c}" stroke="${darken(c, 0.25)}" stroke-width="1.6" stroke-linejoin="round"/>`;
      case 'moon': return `<path d="M104 62 A18 18 0 1 0 104 98 A14 14 0 1 1 104 62Z" fill="${c}" stroke="${darken(c, 0.25)}" stroke-width="1.4"/>`;
      case 'flame': return `<path d="M100 56 Q114 74 105 86 Q114 84 110 98 Q100 108 90 98 Q86 84 95 86 Q86 72 100 56Z" fill="${c}" stroke="${darken(c, 0.2)}" stroke-width="1.6" stroke-linejoin="round"/><path d="M52 124 Q60 108 66 124Z M148 124 Q140 108 134 124Z" fill="${c}" opacity=".9"/>`;
      case 'galaxy': { let s = `<ellipse cx="70" cy="90" rx="38" ry="26" fill="#ff7ad9" opacity=".22"/><ellipse cx="136" cy="118" rx="40" ry="28" fill="#6fb6ff" opacity=".25"/>`; for (let i = 0; i < 22; i++) s += `<circle cx="${R(40, 160)}" cy="${R(60, 165)}" r="${R(0.8, 2.3)}" fill="${c}"/>`; for (let i = 0; i < 4; i++) s += `<path d="${starPath(R(50, 150), R(68, 150), R(3, 5.5), 1.4, 4)}" fill="#fff6c8"/>`; return s; }
      case 'rainbow': return ['#ff7a8a', '#ffb066', '#ffe57f', '#86d98f', '#9ed2ff', '#b79cff'].map((cc, i) => `<path d="M${60 + i * 2} ${80 - i * 0} Q100 ${50 + i * 4} ${140 - i * 2} 80" fill="none" stroke="${cc}" stroke-width="5" stroke-linecap="round" opacity=".9" transform="translate(0 ${i * 4 - 6})"/>`).join('');
      default: return '';
    }
  }

  function furExtras(f, U, rnd) {
    const R = (lo, hi) => lo + rnd() * (hi - lo);
    if (f === 'crystal') return `<g stroke="#fff" stroke-width="1.8" opacity=".7" fill="none"><path d="M100 57 L70 100 L100 170 L130 100Z M70 100 L130 100 M100 57 L100 170"/></g><g fill="#fff">${[0, 1, 2, 3].map(() => `<path d="${starPath(R(50, 150), R(70, 150), 4, 1.2, 4)}"/>`).join('')}</g>`;
    if (f === 'glitch') return `<rect x="30" y="86" width="140" height="7" fill="#35e0ff" opacity=".6"/><rect x="36" y="100" width="130" height="5" fill="#ff5fc8" opacity=".55"/><rect x="30" y="132" width="140" height="8" fill="#ff5fc8" opacity=".45"/><rect x="40" y="148" width="120" height="5" fill="#35e0ff" opacity=".5"/>`;
    if (f === 'void') { let s = ''; for (let i = 0; i < 26; i++) s += `<circle cx="${R(40, 160)}" cy="${R(62, 168)}" r="${R(0.7, 2)}" fill="#fff" opacity="${R(0.4, 1)}"/>`; return s; }
    if (f === 'gold') return `<path d="M60 70 Q80 60 100 64" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".6" fill="none"/>`;
    return '';
  }

  /* ---------- kiegészítők ---------- */
  const ACC = {
    none: () => '',
    bow: (c) => { c = col(c || 'pink'); const d = darken(c, 0.15); return `<g transform="translate(58 66) rotate(-20)"><path d="M0 0 L-21 -13 Q-26 0 -21 13Z" fill="${c}" ${SW2}/><path d="M0 0 L21 -13 Q26 0 21 13Z" fill="${c}" ${SW2}/><circle r="5.6" fill="${d}" ${SW2}/></g>`; },
    crown: (c) => { c = col(c || 'gold'); return `<g transform="translate(100 50)"><path d="M-27 14 L-33 -17 L-15 -4 L0 -23 L15 -4 L33 -17 L27 14Z" fill="${c}" ${SW}/><rect x="-27" y="6" width="54" height="9" rx="3" fill="${darken(c, 0.12)}" ${SW2}/><circle cx="0" cy="10.5" r="3.2" fill="#ff5c7a"/><circle cx="-15" cy="10.5" r="2.8" fill="#6cb8ff"/><circle cx="15" cy="10.5" r="2.8" fill="#8ee89a"/><circle cx="-33" cy="-17" r="3.4" fill="#fff" ${SW2}/><circle cx="33" cy="-17" r="3.4" fill="#fff" ${SW2}/><circle cx="0" cy="-23" r="3.6" fill="#fff" ${SW2}/></g>`; },
    tiara: (c) => { c = col(c || 'gold'); return `<g transform="translate(100 60)"><path d="M-28 8 Q0 -12 28 8" fill="none" stroke="${IN}" stroke-width="8" stroke-linecap="round"/><path d="M-28 8 Q0 -12 28 8" fill="none" stroke="${c}" stroke-width="4.4" stroke-linecap="round"/><path d="M-12 -4 L-8 -16 L-4 -6 L0 -20 L4 -6 L8 -16 L12 -4Z" fill="${c}" ${SW2}/><circle cy="-5" r="3.6" fill="#ff8fb6" ${SW2}/></g>`; },
    tophat: (c) => { c = col(c || 'black'); return `<g transform="translate(100 56) rotate(-8)"><ellipse cy="6" rx="38" ry="8" fill="${c}" ${SW}/><path d="M-24 6 L-22 -34 Q0 -40 22 -34 L24 6Z" fill="${c}" ${SW}/><rect x="-23.5" y="-9" width="47" height="10" fill="#ff8fb6"/><ellipse cy="-34" rx="22" ry="5" fill="${lighten(c, 0.2)}"/></g>`; },
    party: (c) => { c = col(c || 'pink'); return `<g transform="translate(116 52) rotate(16)"><path d="M0 -46 L-21 12 Q0 20 21 12Z" fill="${c}" ${SW}/><path d="M-12 -18 L12 -18 M-17 -2 L17 -2" stroke="#fff" stroke-width="4" opacity=".85"/><circle cy="-48" r="6.4" fill="#ffe57f" ${SW2}/></g>`; },
    wizard: (c) => { c = col(c || 'purple'); return `<g transform="translate(100 56) rotate(-6)"><ellipse cy="8" rx="46" ry="9" fill="${c}" ${SW}/><path d="M-27 8 Q-16 -30 0 -52 Q16 -62 30 -48 Q22 -16 27 8Z" fill="${c}" ${SW}/><path d="M-27 2 Q0 12 27 2 L27 9 Q0 19 -27 9Z" fill="#ffe57f" ${SW2}/><path d="${starPath(-4, -20, 6, 2.6)}" fill="#ffe57f"/><path d="${starPath(10, -34, 4, 1.8)}" fill="#fff"/></g>`; },
    beanie: (c) => { c = col(c || 'black'); return `<g transform="translate(100 50)"><path d="M-38 24 Q-36 -22 0 -24 Q36 -22 38 24 Q0 16 -38 24Z" fill="${c}" ${SW}/><rect x="-40" y="14" width="80" height="14" rx="7" fill="${darken(c, 0.12)}" ${SW}/><circle cy="-26" r="9" fill="#fff" ${SW}/></g>`; },
    phones: (c) => { c = col(c || 'pink'); return `<path d="M44 108 Q44 42 100 42 Q156 42 156 108" fill="none" stroke="${IN}" stroke-width="10" stroke-linecap="round"/><path d="M44 108 Q44 42 100 42 Q156 42 156 108" fill="none" stroke="#fff" stroke-width="5.6" stroke-linecap="round"/><ellipse cx="42" cy="116" rx="12" ry="19" fill="${c}" ${SW}/><ellipse cx="158" cy="116" rx="12" ry="19" fill="${c}" ${SW}/><ellipse cx="42" cy="116" rx="5.4" ry="10" fill="#fff" opacity=".7"/><ellipse cx="158" cy="116" rx="5.4" ry="10" fill="#fff" opacity=".7"/>`; },
    glasses: (c) => { c = col(c || 'black'); return `<g fill="rgba(255,255,255,.28)" stroke="${c}" stroke-width="3.8"><circle cx="74" cy="114" r="18"/><circle cx="126" cy="114" r="18"/></g><path d="M92 112 Q100 106 108 112 M56 110 L38 104 M144 110 L162 104" stroke="${c}" stroke-width="3.6" fill="none" stroke-linecap="round"/>`; },
    shades: (c) => { c = col(c || 'black'); return `<g fill="${c}" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"><path d="M52 104 H94 V118 Q94 134 73 134 Q52 134 52 118Z"/><path d="M106 104 H148 V118 Q148 134 127 134 Q106 134 106 118Z"/></g><path d="M94 108 H106" stroke="${IN}" stroke-width="3.2"/><path d="M58 110 L78 110 M112 110 L132 110" stroke="#fff" stroke-width="2.6" opacity=".55" stroke-linecap="round"/>`; },
    flower: (c) => { c = col(c || 'pink'); let p = ''; for (let k = 0; k < 5; k++) { const a = (k * 72 * Math.PI) / 180; p += `<circle cx="${Math.cos(a) * 8.4}" cy="${Math.sin(a) * 8.4}" r="6.6" fill="${c}" ${SW2}/>`; } return `<g transform="translate(146 66)">${p}<circle r="5.4" fill="#ffd95e" ${SW2}/></g>`; },
    halo: () => `<ellipse cx="100" cy="36" rx="30" ry="9" fill="none" stroke="#fff6a8" stroke-width="12" opacity=".55"/><ellipse cx="100" cy="36" rx="30" ry="9" fill="none" stroke="#ffd25a" stroke-width="6"/><ellipse cx="100" cy="36" rx="30" ry="9" fill="none" stroke="${IN}" stroke-width="1.4" opacity=".5"/>`,
    horns: (c) => { c = col(c || 'red'); return `<path d="M60 76 Q54 50 74 40 Q72 60 84 72Z" fill="${c}" ${SW}/><path d="M140 76 Q146 50 126 40 Q128 60 116 72Z" fill="${c}" ${SW}/>`; },
    scarf: (c) => { c = col(c || 'red'); return `<path d="M54 160 Q100 184 146 160 Q150 172 144 180 Q100 198 56 180 Q50 170 54 160Z" fill="${c}" ${SW}/><path d="M118 184 L128 210 L108 208 L104 188Z" fill="${c}" ${SW}/><path d="M68 170 L74 186 M90 176 L94 192 M112 176 L112 190 M132 170 L128 184" stroke="#fff" stroke-width="3.4" opacity=".7" stroke-linecap="round"/>`; },
    bandana: (c) => { c = col(c || 'red'); return `<path d="M56 158 Q100 174 144 158 L100 202Z" fill="${c}" ${SW}/><g fill="#fff" opacity=".85"><circle cx="86" cy="170" r="2.6"/><circle cx="108" cy="172" r="2.6"/><circle cx="98" cy="184" r="2.6"/><circle cx="122" cy="166" r="2.2"/><circle cx="76" cy="164" r="2.2"/></g>`; },
    bowtie: (c) => { c = col(c || 'red'); return `<g transform="translate(100 174)"><path d="M0 0 L-22 -12 L-22 12Z" fill="${c}" ${SW2}/><path d="M0 0 L22 -12 L22 12Z" fill="${c}" ${SW2}/><circle r="5.4" fill="${darken(c, 0.15)}" ${SW2}/></g>`; },
    bell: (c) => { c = col(c || 'gold'); return `<path d="M56 160 Q100 184 144 160" fill="none" stroke="${IN}" stroke-width="11" stroke-linecap="round"/><path d="M56 160 Q100 184 144 160" fill="none" stroke="${c}" stroke-width="6.6" stroke-linecap="round"/><circle cx="100" cy="182" r="9.4" fill="#ffd25a" ${SW2}/><path d="M91 182 H109" stroke="${IN}" stroke-width="2"/><circle cx="100" cy="187" r="2" fill="${IN}"/>`; },
    mushroom: (c) => { c = col(c || 'red'); return `<g transform="translate(100 54)"><path d="M-44 16 Q-46 -32 0 -34 Q46 -32 44 16 Q0 26 -44 16Z" fill="${c}" ${SW}/><circle cx="-22" cy="-8" r="6.4" fill="#fff"/><circle cx="6" cy="-18" r="7.4" fill="#fff"/><circle cx="26" cy="-2" r="5.4" fill="#fff"/><circle cx="-4" cy="6" r="4.2" fill="#fff"/></g>`; },
    leaf: (c) => { c = col(c || 'green'); return `<g transform="translate(100 62)"><path d="M0 0 Q-24 -10 -28 -36 Q-4 -32 0 0Z" fill="${c}" ${SW2}/><path d="M0 0 Q24 -10 28 -36 Q4 -32 0 0Z" fill="${lighten(c, 0.25)}" ${SW2}/><path d="M0 0 L0 -14" stroke="${IN}" stroke-width="2.4" stroke-linecap="round"/></g>`; },
    chef: () => `<g transform="translate(100 54)"><circle cx="-19" cy="-12" r="15" fill="#fff" ${SW}/><circle cx="0" cy="-22" r="17" fill="#fff" ${SW}/><circle cx="19" cy="-12" r="15" fill="#fff" ${SW}/><rect x="-28" y="-6" width="56" height="20" rx="5" fill="#fff" ${SW}/><path d="M-14 -4 V12 M0 -4 V12 M14 -4 V12" stroke="#e5e0ef" stroke-width="2.4"/></g>`,
    pirate: () => `<g transform="translate(100 52)"><path d="M-46 14 Q-36 -30 0 -32 Q36 -30 46 14 Q0 4 -46 14Z" fill="#3a3350" ${SW}/><circle cy="-12" r="7" fill="#fff"/><circle cx="-2.6" cy="-13" r="1.8" fill="${IN}"/><circle cx="2.6" cy="-13" r="1.8" fill="${IN}"/><path d="M-9 -2 L9 6 M9 -2 L-9 6" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/></g><path d="M113 104 L66 84 M139 104 L156 88" stroke="#2e2640" stroke-width="3"/><ellipse cx="126" cy="114" rx="15" ry="13" fill="#2e2640" ${SW2}/>`,
    santa: () => `<g transform="translate(100 52)"><path d="M-42 14 Q-40 -28 -2 -34 Q26 -38 46 -10 L38 16 Q-2 22 -42 14Z" fill="#ff5c6c" ${SW}/><rect x="-46" y="6" width="90" height="19" rx="9.5" fill="#fff" ${SW}/><circle cx="46" cy="-10" r="9.4" fill="#fff" ${SW}/></g>`,
    bunny: (c) => { c = col(c || 'pink'); return `<path d="M60 74 Q100 58 140 74" fill="none" stroke="${c}" stroke-width="7" stroke-linecap="round"/><g ${SW}><path d="M72 66 Q58 14 78 6 Q94 10 90 62Z" fill="#fff"/><path d="M128 66 Q142 14 122 6 Q106 10 110 62Z" fill="#fff"/></g><path d="M77 56 Q68 22 79 15 Q86 20 85 54Z M123 56 Q132 22 121 15 Q114 20 115 54Z" fill="${c}"/>`; },
    sprout: (c) => { c = col(c || 'green'); return `<g transform="translate(100 60)"><path d="M0 0 Q0 -14 2 -22" stroke="${IN}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M0 0 Q0 -14 2 -22" stroke="#6fcf7a" stroke-width="3.4" fill="none" stroke-linecap="round"/><path d="M2 -22 Q-18 -32 -26 -18 Q-8 -10 2 -22Z" fill="${c}" ${SW2}/><path d="M2 -22 Q22 -36 30 -22 Q14 -12 2 -22Z" fill="${lighten(c, 0.2)}" ${SW2}/></g>`; },
    icecream: (c) => { c = col(c || 'pink'); return `<g transform="translate(100 60)"><ellipse cy="-2" rx="28" ry="11" fill="${c}" ${SW}/><ellipse cy="-15" rx="21" ry="10" fill="${lighten(c, 0.2)}" ${SW}/><ellipse cy="-27" rx="13" ry="8" fill="${c}" ${SW}/><circle cy="-38" r="5.4" fill="#ff5c7a" ${SW2}/><g fill="#fff"><rect x="-12" y="-6" width="5" height="2.4" rx="1" transform="rotate(20 -10 -5)"/><rect x="6" y="-18" width="5" height="2.4" rx="1" transform="rotate(-20 8 -17)"/><rect x="12" y="-4" width="5" height="2.4" rx="1"/></g></g>`; },
    cap: (c) => { c = col(c || 'red'); return `<g transform="translate(100 52)"><path d="M-40 22 Q-42 -28 0 -30 Q42 -28 40 22 Q0 14 -40 22Z" fill="${c}" ${SW}/><path d="M10 16 Q52 6 64 24 Q40 30 10 24Z" fill="${darken(c, 0.15)}" ${SW}/><circle cy="-30" r="4.4" fill="${darken(c, 0.15)}" ${SW2}/><path d="M0 -29 Q-5 -6 -2 17" stroke="${IN}" stroke-width="1.8" fill="none" opacity=".5"/></g>`; },
    butterfly: (c) => { c = col(c || 'blue'); return `<g transform="translate(62 62) rotate(-15)"><ellipse cx="-10" cy="-6" rx="11" ry="8" fill="${c}" ${SW2} transform="rotate(-20 -10 -6)"/><ellipse cx="10" cy="-6" rx="11" ry="8" fill="${c}" ${SW2} transform="rotate(20 10 -6)"/><ellipse cx="-8" cy="6" rx="7" ry="6" fill="${lighten(c, 0.3)}" ${SW2}/><ellipse cx="8" cy="6" rx="7" ry="6" fill="${lighten(c, 0.3)}" ${SW2}/><rect x="-1.8" y="-9" width="3.6" height="18" rx="1.8" fill="${IN}"/></g>`; },
    strawberry: () => `<g transform="translate(100 54)"><path d="M-38 16 Q-42 -24 0 -26 Q42 -24 38 16 Q0 32 -38 16Z" fill="#ff6b81" ${SW}/><g fill="#ffe57f"><ellipse cx="-18" cy="-6" rx="2" ry="3"/><ellipse cx="2" cy="-12" rx="2" ry="3"/><ellipse cx="20" cy="-4" rx="2" ry="3"/><ellipse cx="-8" cy="8" rx="2" ry="3"/><ellipse cx="12" cy="10" rx="2" ry="3"/></g><path d="M-18 -26 L-11 -40 L-4 -29 L0 -44 L5 -29 L12 -40 L18 -26Z" fill="#6fcf7a" ${SW2}/></g>`,
    sailor: (c) => { c = col(c || 'blue'); return `<g transform="translate(100 54)"><ellipse cy="8" rx="42" ry="10" fill="#fff" ${SW}/><path d="M-32 8 Q-30 -22 0 -24 Q30 -22 32 8Z" fill="#fff" ${SW}/><path d="M-32 -2 Q0 8 32 -2 L32 6 Q0 14 -32 6Z" fill="${c}" ${SW2}/></g>`; },
    antenna: (c) => { c = col(c || 'pink'); return `<path d="M58 78 Q100 60 142 78" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round"/><path d="M84 64 Q76 42 68 30 M116 64 Q124 42 132 30" fill="none" stroke="${IN}" stroke-width="3.4" stroke-linecap="round"/><circle cx="68" cy="27" r="7.4" fill="${c}" ${SW2}/><circle cx="132" cy="27" r="7.4" fill="${c}" ${SW2}/><circle cx="66" cy="24" r="2" fill="#fff"/><circle cx="130" cy="24" r="2" fill="#fff"/>`; },
    cherries: () => `<g transform="translate(100 56)"><path d="M0 -26 Q-14 -18 -16 6 M0 -26 Q12 -18 16 4" fill="none" stroke="${IN}" stroke-width="3" stroke-linecap="round"/><path d="M0 -26 Q10 -40 24 -32 Q14 -22 0 -26Z" fill="#6fcf7a" ${SW2}/><circle cx="-16" cy="10" r="11" fill="#ff5c7a" ${SW}/><circle cx="16" cy="8" r="11" fill="#ff5c7a" ${SW}/><circle cx="-19" cy="6" r="2.6" fill="#fff" opacity=".8"/><circle cx="13" cy="4" r="2.6" fill="#fff" opacity=".8"/></g>`,
    wings: (c) => { c = col(c || 'white'); const L = `<path d="M70 172 Q8 160 6 104 Q34 108 50 128 Q30 112 28 90 Q60 100 72 138Z" fill="${c}" ${SW}/>`; return L + `<g transform="translate(200 0) scale(-1 1)">${L}</g>`; },
  };
  const BACK_ACC = new Set(['wings']);

  /* ---------- fő cica ---------- */
  function catMarkup(card, o) {
    o = o || {};
    const U = '@U@';
    const rnd = rng((card.id || 1) * 7919 + 13);
    const opt = card.opt || {};
    const sp = SPECIAL[card.fur];
    const base = sp || col(card.fur);
    const fill = sp ? `url(#fur${U})` : base;
    const inner = opt.inner ? col(opt.inner) : '#ffa5c0';
    const pat = parse(card.pat);
    const eyes = parse(card.eyes);
    const accs = String(card.acc || 'none').split('+').map(parse);
    const tailKind = opt.tail || ['curl', 'up', 'fluff'][(card.id || 0) % 3];
    const earType = opt.ear || 'pointy';
    const mouth = opt.mouth || 'w';
    const earFill = pat.n === 'siam' ? col(pat.c) : fill;
    const tuft = darken(base, 0.25);
    const muz = sp ? 'rgba(255,255,255,.55)' : lighten(base, 0.62);

    let s = `<defs>${furDefs(card.fur, U)}<radialGradient id="hl${U}" cx=".35" cy=".25" r=".75"><stop offset="0" stop-color="#fff" stop-opacity=".6"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient><linearGradient id="sh${U}" x1="0" y1="0" x2="0" y2="1"><stop offset=".55" stop-color="#7a4a7a" stop-opacity="0"/><stop offset="1" stop-color="#7a4a7a" stop-opacity=".22"/></linearGradient><clipPath id="cl${U}"><ellipse cx="100" cy="112" rx="66" ry="55"/></clipPath></defs>`;
    if (o.bg !== false) s += bgMarkup(card.bg, U, rnd);
    if (o.shadow !== false) s += `<ellipse cx="100" cy="194" rx="62" ry="8" fill="#4a3552" opacity=".13"/>`;
    accs.forEach((a) => { if (BACK_ACC.has(a.n) && ACC[a.n]) s += ACC[a.n](a.c); });

    // farok
    const tp = { curl: 'M138 198 Q196 198 188 146 Q184 126 168 134', up: 'M142 198 Q184 180 172 118', fluff: 'M138 198 Q186 206 190 160 Q192 134 172 128' }[tailKind] || 'M138 198 Q196 198 188 146';
    const tw = tailKind === 'fluff' ? 20 : 15;
    s += `<path d="${tp}" fill="none" stroke="${IN}" stroke-width="${tw + 6}" stroke-linecap="round"/><path d="${tp}" fill="none" stroke="${sp ? lighten(base, 0.1) : base}" stroke-width="${tw}" stroke-linecap="round"/>`;
    // test
    s += `<ellipse cx="100" cy="198" rx="56" ry="44" fill="${fill}" ${SW}/><ellipse cx="100" cy="204" rx="30" ry="28" fill="${muz}"/>`;
    // mancsok
    s += `<ellipse cx="72" cy="186" rx="15" ry="11" fill="${fill}" ${SW}/><ellipse cx="128" cy="186" rx="15" ry="11" fill="${fill}" ${SW}/><path d="M68 188 V193 M76 188 V193 M124 188 V193 M132 188 V193" stroke="${IN}" stroke-width="1.8" stroke-linecap="round" opacity=".5"/>`;
    // fülek + fej
    s += earMarkup(earType, earFill, inner, tuft);
    s += `<ellipse cx="100" cy="112" rx="66" ry="55" fill="${fill}"/>`;
    s += `<g clip-path="url(#cl${U})">${patMarkup(pat, base, U, rnd, card.fur)}${furExtras(card.fur, U, rnd)}</g>`;
    s += `<ellipse cx="100" cy="112" rx="66" ry="55" fill="url(#hl${U})"/><ellipse cx="100" cy="112" rx="66" ry="55" fill="url(#sh${U})"/><ellipse cx="100" cy="112" rx="66" ry="55" fill="none" ${SW}/>`;
    if (!opt.nomuz) s += `<ellipse cx="100" cy="137" rx="25" ry="17" fill="${muz}" opacity=".9"/>`;
    // szemek
    const etype = eyes.n;
    const ex = (side) => (side < 0 ? 74 : 126);
    const mk = (t, side) => `<g transform="translate(${ex(side)} 114)${side > 0 ? ' scale(-1 1)' : ''}">${eyeMarkup(t, eyes.c, side)}</g>`;
    if (etype === 'wink') s += mk('round', -1) + mk('happy', 1);
    else s += mk(etype, -1) + mk(etype, 1);
    if (!opt.noblush) s += `<ellipse cx="52" cy="132" rx="11" ry="6.4" fill="#ff7fa8" opacity=".5"/><ellipse cx="148" cy="132" rx="11" ry="6.4" fill="#ff7fa8" opacity=".5"/>`;
    // orr + száj
    s += `<path d="M94 126 Q100 123 106 126 Q103 133 100 134 Q97 133 94 126Z" fill="${opt.nose ? col(opt.nose) : '#ff7f9f'}" stroke="${IN}" stroke-width="1.8" stroke-linejoin="round"/>`;
    s += mouthMarkup(mouth);
    if (opt.whisk !== '0') s += `<g stroke="${IN}" stroke-opacity=".38" stroke-width="2" stroke-linecap="round" fill="none"><path d="M40 124 L14 117 M40 132 L12 132 M42 140 L16 147"/><path d="M160 124 L186 117 M160 132 L188 132 M158 140 L184 147"/></g>`;
    accs.forEach((a) => { if (!BACK_ACC.has(a.n) && ACC[a.n]) s += ACC[a.n](a.c); });
    return s;
  }

  const TPL = {};
  let UID = 0;
  const inst = (t) => t.replace(/@U@/g, () => '').replace(/@U@/g, '') && t;
  function wrap(inner, cls) {
    const u = ++UID;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 200" preserveAspectRatio="xMidYMid slice" class="${cls || 'catsvg'}">${inner.split('@U@').join('_' + u)}</svg>`;
  }
  function cardArt(card) {
    const k = 'c' + card.id;
    if (!TPL[k]) TPL[k] = catMarkup(card);
    return wrap(TPL[k]);
  }
  function catOnly(card, cls) { return wrap(catMarkup(card, { bg: false }), cls); }
  function mascot(extra) {
    const card = Object.assign({ id: 77, fur: 'white', pat: 'calico:gray', eyes: 'happy', acc: 'none', bg: '', opt: { mouth: 'open', ear: 'pointy', tail: 'up' } }, extra || {});
    return wrap(catMarkup(card, { bg: false }), 'catsvg mascot');
  }
  function qCat() { return ''; }

  /* ================= CSOMAG + KÁRTYAHÁT ================= */
  function packSVG(kind) {
    const P = (w.KData && w.KData.PACKS[kind]) || { c1: '#ffb8d8', c2: '#ff7fb5', name: 'Csomag' };
    const u = ++UID;
    const zig = (y, dir) => { let d = ''; for (let x = 8; x <= 152; x += 8) d += `L${x} ${y + ((x / 8) % 2 ? dir * 7 : 0)} `; return d; };
    const body = `M8 ${20} ${zig(20, -1)} L152 20 L152 230 ${zig(230, 1).split(' ').reverse().join(' ') ? '' : ''}`;
    let top = 'M8 24 '; for (let x = 8; x <= 152; x += 8) top += `L${x} ${(x / 8) % 2 ? 14 : 24} `;
    let bot = ''; for (let x = 152; x >= 8; x -= 8) bot += `L${x} ${(x / 8) % 2 ? 236 : 226} `;
    const path = top + 'L152 24 L152 228 ' + bot + 'Z';
    const rb = kind === 'rainbow';
    const cat = catMarkup({ id: 5, fur: kind === 'gold' ? 'cream' : 'white', pat: 'calico:' + (kind === 'silver' ? 'gray' : 'ginger'), eyes: 'happy', acc: kind === 'gold' ? 'crown:gold' : kind === 'basic' ? 'bow:pink' : kind === 'silver' ? 'wizard:purple' : 'tiara:gold+bow:pink', bg: '', opt: { mouth: 'open', whisk: '0', tail: 'none' } }, { bg: false, shadow: false });
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 250" class="packsvg"><defs><linearGradient id="pk${u}" x1="0" y1="0" x2="1" y2="1">${rb ? '<stop offset="0" stop-color="#ff9ad5"/><stop offset=".35" stop-color="#ffe27a"/><stop offset=".65" stop-color="#8ee8c0"/><stop offset="1" stop-color="#9ab8ff"/>' : `<stop offset="0" stop-color="${P.c1}"/><stop offset="1" stop-color="${P.c2}"/>`}</linearGradient><linearGradient id="ps${u}" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity="0"/><stop offset=".5" stop-color="#fff" stop-opacity=".45"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient><clipPath id="pc${u}"><path d="${path}"/></clipPath></defs>
<path d="${path}" fill="url(#pk${u})" stroke="${IN}" stroke-width="4" stroke-linejoin="round"/>
<g clip-path="url(#pc${u})"><rect x="0" y="10" width="160" height="34" fill="#fff" opacity=".28"/><rect x="0" y="206" width="160" height="40" fill="#fff" opacity=".28"/>
${[0, 1, 2, 3, 4, 5].map((i) => `<path d="${starPath(20 + (i * 53) % 130, 60 + (i * 37) % 130, 5 + (i % 3) * 2, 2, 4)}" fill="#fff" opacity=".7"/>`).join('')}
<circle cx="80" cy="118" r="52" fill="#fff" opacity=".35"/><circle cx="80" cy="118" r="46" fill="${kind === 'rainbow' ? '#fff0fa' : '#fff7fb'}" stroke="${IN}" stroke-width="3"/>
<g transform="translate(36 78) scale(.44)">${cat.split('@U@').join('_p' + u)}</g>
<rect x="-30" y="0" width="40" height="260" fill="url(#ps${u})" transform="rotate(20 80 125)"><animate attributeName="x" values="-60;190;190" dur="3.4s" repeatCount="indefinite"/></rect></g>
<path d="M18 176 Q80 190 142 176 L142 204 Q80 218 18 204Z" fill="#fff" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/>
<text x="80" y="195" text-anchor="middle" font-family="Fredoka Variable,Fredoka,sans-serif" font-weight="700" font-size="14" fill="${P.c2 === '#ff9ad5' ? '#c64fa3' : darken(P.c2, 0.25)}">${(P.name || '').split(' ')[0].toUpperCase()}</text>
<text x="80" y="43" text-anchor="middle" font-family="Fredoka Variable,Fredoka,sans-serif" font-weight="700" font-size="15" fill="#fff" stroke="${IN}" stroke-width="3.4" paint-order="stroke">Kitticskek</text>
<path d="${starPath(26, 128, 8, 3.4)}" fill="#fff6a8" stroke="${IN}" stroke-width="2" stroke-linejoin="round"/><path d="${starPath(134, 132, 8, 3.4)}" fill="#fff6a8" stroke="${IN}" stroke-width="2" stroke-linejoin="round"/></svg>`;
  }

  function cardBack() {
    const u = ++UID;
    let paws = '';
    for (let y = 0; y < 5; y++) for (let x = 0; x < 4; x++) paws += `<g transform="translate(${x * 50 + (y % 2) * 25 - 10} ${y * 48 + 6}) scale(.5)" fill="#fff" opacity=".28"><ellipse cx="25" cy="30" rx="14" ry="11"/><circle cx="8" cy="16" r="5"/><circle cx="20" cy="9" r="5"/><circle cx="32" cy="9" r="5"/><circle cx="44" cy="16" r="5"/></g>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 300" preserveAspectRatio="xMidYMid slice" class="backsvg"><defs><linearGradient id="cb${u}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ff9ccf"/><stop offset=".55" stop-color="#c9a6ff"/><stop offset="1" stop-color="#8fc6ff"/></linearGradient></defs><rect width="200" height="300" fill="url(#cb${u})"/>${paws}<rect x="10" y="10" width="180" height="280" rx="18" fill="none" stroke="#fff" stroke-width="4" opacity=".85"/><circle cx="100" cy="150" r="52" fill="#fff" opacity=".35"/><g transform="translate(100 150)"><ellipse cx="0" cy="12" rx="26" ry="21" fill="#fff" stroke="${IN}" stroke-width="3.4"/><circle cx="-30" cy="-14" r="11" fill="#fff" stroke="${IN}" stroke-width="3.4"/><circle cx="-10" cy="-32" r="11" fill="#fff" stroke="${IN}" stroke-width="3.4"/><circle cx="10" cy="-32" r="11" fill="#fff" stroke="${IN}" stroke-width="3.4"/><circle cx="30" cy="-14" r="11" fill="#fff" stroke="${IN}" stroke-width="3.4"/></g><path d="${starPath(48, 50, 12, 5)}" fill="#fff6a8" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"/><path d="${starPath(152, 250, 12, 5)}" fill="#fff6a8" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"/></svg>`;
  }

  /* ================= IKONOK ================= */
  const ICONS = {
    home: `<path d="M10 32 L32 12 L54 32" fill="none" stroke="#fff" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 30 V52 H27 V38 H37 V52 H48 V30 L32 17Z" fill="#fff"/>`,
    gear: `<g fill="#fff"><circle cx="32" cy="32" r="15"/>${[0, 45, 90, 135, 180, 225, 270, 315].map((a) => `<rect x="27" y="6" width="10" height="13" rx="3" transform="rotate(${a} 32 32)"/>`).join('')}</g><circle cx="32" cy="32" r="7" fill="#5b6a8c"/>`,
    cards: `<g transform="rotate(-10 32 34)"><rect x="12" y="10" width="34" height="46" rx="6" fill="#c6a7ff" stroke="${IN}" stroke-width="3"/></g><g transform="rotate(8 32 34)"><rect x="18" y="8" width="34" height="46" rx="6" fill="#ff9ccf" stroke="${IN}" stroke-width="3"/><path d="M26 34 L26 24 L31 28 H39 L44 24 V34 Q44 44 35 44 Q26 44 26 34Z" fill="#fff" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"/><circle cx="31" cy="35" r="1.5" fill="${IN}"/><circle cx="39" cy="35" r="1.5" fill="${IN}"/></g>`,
    shop: `<path d="M12 30 H52 V54 H12Z" fill="#fff6e8" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><path d="M8 14 H56 L60 28 Q56 34 52 28 Q48 34 44 28 Q40 34 36 28 Q32 34 28 28 Q24 34 20 28 Q16 34 12 28 Q8 34 4 28Z" fill="#ff7a96" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><path d="M20 14 L18 28 M32 14 V28 M44 14 L46 28" stroke="#fff" stroke-width="4"/><rect x="18" y="36" width="12" height="18" rx="2" fill="#ff9ccf" stroke="${IN}" stroke-width="2.4"/><rect x="35" y="36" width="12" height="10" rx="2" fill="#9ed2ff" stroke="${IN}" stroke-width="2.4"/>`,
    trophy: `<path d="M18 8 H46 V26 Q46 40 32 42 Q18 40 18 26Z" fill="#ffd25a" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><path d="M18 14 H8 Q8 28 20 30 M46 14 H56 Q56 28 44 30" fill="none" stroke="${IN}" stroke-width="3" stroke-linecap="round"/><rect x="28" y="42" width="8" height="8" fill="#e8a92a" stroke="${IN}" stroke-width="2.4"/><rect x="20" y="50" width="24" height="8" rx="3" fill="#ffd25a" stroke="${IN}" stroke-width="3"/><path d="${starPath(32, 24, 7, 3)}" fill="#fff" stroke="${IN}" stroke-width="1.8" stroke-linejoin="round"/>`,
    pack: `<path d="M16 12 L20 8 L24 12 L28 8 L32 12 L36 8 L40 12 L44 8 L48 12 V54 L44 58 L40 54 L36 58 L32 54 L28 58 L24 54 L20 58 L16 54Z" fill="#c6a7ff" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="34" r="12" fill="#fff" stroke="${IN}" stroke-width="2.4"/><path d="M26 36 V28 L30 31 H34 L38 28 V36 Q38 42 32 42 Q26 42 26 36Z" fill="#ffb8d2" stroke="${IN}" stroke-width="2" stroke-linejoin="round"/>`,
    coin: `<circle cx="32" cy="32" r="26" fill="#ffd25a" stroke="${IN}" stroke-width="3.4"/><circle cx="32" cy="32" r="19" fill="#ffe486" stroke="#e5a52f" stroke-width="2.4"/><ellipse cx="32" cy="38" rx="8" ry="6.4" fill="#e5a52f"/><circle cx="21" cy="30" r="3.2" fill="#e5a52f"/><circle cx="27" cy="22" r="3.2" fill="#e5a52f"/><circle cx="37" cy="22" r="3.2" fill="#e5a52f"/><circle cx="43" cy="30" r="3.2" fill="#e5a52f"/><path d="M16 22 Q20 14 28 12" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" opacity=".8"/>`,
    plus: `<path d="M32 14 V50 M14 32 H50" stroke="#fff" stroke-width="9" stroke-linecap="round"/>`,
    back: `<path d="M40 12 L20 32 L40 52" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>`,
    play: `<path d="M20 12 L52 32 L20 52Z" fill="#fff" stroke="#fff" stroke-width="6" stroke-linejoin="round"/>`,
    close: `<path d="M16 16 L48 48 M48 16 L16 48" stroke="#fff" stroke-width="9" stroke-linecap="round"/>`,
    music: `<path d="M24 46 V16 L48 10 V40" fill="none" stroke="#fff" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"/><circle cx="18" cy="46" r="8" fill="#fff"/><circle cx="42" cy="40" r="8" fill="#fff"/>`,
    sound: `<path d="M10 24 H22 L36 12 V52 L22 40 H10Z" fill="#fff" stroke="#fff" stroke-width="4" stroke-linejoin="round"/><path d="M44 22 Q52 32 44 42 M50 14 Q64 32 50 50" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round"/>`,
    gift: `<rect x="10" y="26" width="44" height="30" rx="5" fill="#ff9ccf" stroke="${IN}" stroke-width="3"/><rect x="7" y="18" width="50" height="12" rx="4" fill="#ffb8d8" stroke="${IN}" stroke-width="3"/><rect x="28" y="18" width="8" height="38" fill="#ffe27a" stroke="${IN}" stroke-width="2.4"/><path d="M32 18 Q20 2 16 10 Q14 18 32 18 Q50 18 48 10 Q44 2 32 18Z" fill="#ffe27a" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"/>`,
    star: `<path d="${starPath(32, 33, 26, 11)}" fill="#ffd25a" stroke="${IN}" stroke-width="3.4" stroke-linejoin="round"/>`,
    heart: `<path d="${heartPath(32, 30, 18)}" fill="#ff7a9c" stroke="${IN}" stroke-width="3.4" stroke-linejoin="round"/>`,
    paw: `<g fill="#fff"><ellipse cx="32" cy="42" rx="14" ry="11"/><circle cx="12" cy="28" r="6"/><circle cx="25" cy="16" r="6"/><circle cx="39" cy="16" r="6"/><circle cx="52" cy="28" r="6"/></g>`,
    lock: `<rect x="14" y="28" width="36" height="28" rx="7" fill="#c9bfe0" stroke="${IN}" stroke-width="3"/><path d="M22 28 V20 Q22 10 32 10 Q42 10 42 20 V28" fill="none" stroke="${IN}" stroke-width="4"/>`,
    check: `<path d="M14 34 L27 47 L50 18" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>`,
    left: `<path d="M40 12 L20 32 L40 52" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>`,
    right: `<path d="M24 12 L44 32 L24 52" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round" stroke-linejoin="round"/>`,
    sparkle: `<path d="${starPath(32, 32, 28, 6, 4)}" fill="#fff6a8" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"/>`,
    fish: `<path d="M8 32 Q24 10 44 28 L58 16 V48 L44 36 Q24 54 8 32Z" fill="#9ed2ff" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><circle cx="20" cy="30" r="3" fill="${IN}"/>`,
  };
  function icon(name, cls) { return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" class="ico ${cls || ''}">${ICONS[name] || ''}</svg>`; }

  /* ================= KARAKTEREK (saját chibi gyerekek) ================= */
  function chibi(k) {
    const o = {
      pink: { skin: '#f0b48a', hair: '#ff9ccf', hair2: '#ff7ab8', top: '#ffb8d8', bottom: '#7b7f95', style: 'buns', shoes: '#fff' },
      brown: { skin: '#f3c09a', hair: '#6b4535', hair2: '#4a2e22', top: '#fff0d9', bottom: '#4a4560', style: 'long', shoes: '#6b4535' },
      boy: { skin: '#b97a56', hair: '#2e2a3a', hair2: '#1e1a28', top: '#3a3550', bottom: '#2a2638', style: 'beanie', shoes: '#fff' },
    }[k];
    const u = ++UID;
    const face = (tilt) => `<g>
      <path d="M72 106 Q80 98 88 106" fill="none" stroke="${IN}" stroke-width="4" stroke-linecap="round"/><path d="M112 106 Q120 98 128 106" fill="none" stroke="${IN}" stroke-width="4" stroke-linecap="round"/>
      <ellipse cx="68" cy="122" rx="9" ry="6" fill="#ff7fa8" opacity=".55"/><ellipse cx="132" cy="122" rx="9" ry="6" fill="#ff7fa8" opacity=".55"/>
      <path d="M90 118 Q100 136 110 118Z" fill="#7a2f4d" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><path d="M94 127 Q100 122 106 127 Q100 133 94 127Z" fill="#ff8fa8"/></g>`;
    const hoodie = (cat) => `<path d="M62 168 Q60 150 100 148 Q140 150 138 168 L142 236 Q100 246 58 236Z" fill="${o.top}" ${SW}/>
      <path d="M84 150 Q100 166 116 150" fill="none" stroke="${IN}" stroke-width="3" stroke-linecap="round"/>${cat ? `<g transform="translate(100 208)"><path d="M-14 6 V-10 L-7 -5 H7 L14 -10 V6 Q14 14 0 14 Q-14 14 -14 6Z" fill="${cat}" stroke="${IN}" stroke-width="2.4" stroke-linejoin="round"/><circle cx="-5" cy="3" r="1.6" fill="${IN}"/><circle cx="5" cy="3" r="1.6" fill="${IN}"/></g>` : ''}`;
    const legs = `<path d="M70 236 L66 280 H92 L94 240Z" fill="${o.skin}" ${SW}/><path d="M130 236 L134 280 H108 L106 240Z" fill="${o.skin}" ${SW}/><path d="M56 276 Q54 292 70 292 H96 V276Z" fill="${o.shoes}" ${SW}/><path d="M144 276 Q146 292 130 292 H104 V276Z" fill="${o.shoes}" ${SW}/>`;
    let back = '', front = '', arms = '';
    if (o.style === 'long') back = `<path d="M44 100 Q40 40 100 40 Q160 40 156 100 Q168 170 150 232 Q130 240 124 200 L76 200 Q70 240 50 232 Q32 170 44 100Z" fill="${o.hair}" ${SW}/>`;
    if (o.style === 'buns') back = `<circle cx="52" cy="52" r="20" fill="${o.hair}" ${SW}/><circle cx="148" cy="52" r="20" fill="${o.hair}" ${SW}/><path d="M42 100 Q36 44 100 40 Q164 44 158 100 Q150 150 140 160 L60 160 Q50 150 42 100Z" fill="${o.hair}" ${SW}/>`;
    if (o.style === 'beanie') back = `<path d="M50 110 Q48 60 100 56 Q152 60 150 110Z" fill="${o.hair}" ${SW}/>`;
    const head = `<ellipse cx="100" cy="106" rx="54" ry="50" fill="${o.skin}" ${SW}/>`;
    if (o.style === 'long') front = `<path d="M46 98 Q46 52 100 50 Q154 52 154 98 Q140 66 118 76 Q96 62 78 78 Q58 70 46 98Z" fill="${o.hair}" ${SW}/>`;
    if (o.style === 'buns') front = `<path d="M46 96 Q48 54 100 52 Q152 54 154 96 Q140 74 122 82 Q104 66 86 82 Q66 72 46 96Z" fill="${o.hair}" ${SW}/><g transform="translate(66 76)"><path d="M-9 4 V-8 L-4 -4 H4 L9 -8 V4 Q9 10 0 10 Q-9 10 -9 4Z" fill="#fff" stroke="${IN}" stroke-width="2" stroke-linejoin="round"/></g>`;
    if (o.style === 'beanie') front = `<path d="M44 84 Q44 38 100 36 Q156 38 156 84 Q100 74 44 84Z" fill="${o.hair}" ${SW}/><rect x="42" y="76" width="116" height="18" rx="9" fill="${o.hair2}" ${SW}/><circle cx="100" cy="30" r="12" fill="${o.hair}" ${SW}/><g transform="translate(132 86)"><path d="M-8 4 V-7 L-4 -4 H4 L8 -7 V4 Q8 9 0 9 Q-8 9 -8 4Z" fill="#fff" stroke="${IN}" stroke-width="2" stroke-linejoin="round"/></g>`;
    let extra = '';
    if (k === 'brown') extra = `<path d="M58 70 L48 34 L82 56Z" fill="#fff" ${SW}/><path d="M142 70 L152 34 L118 56Z" fill="#fff" ${SW}/><path d="M60 62 L54 44 L74 56Z" fill="#ffb8d2"/><path d="M140 62 L146 44 L126 56Z" fill="#ffb8d2"/><path d="M44 104 Q44 44 100 44 Q156 44 156 104" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round"/><path d="M44 104 Q44 44 100 44 Q156 44 156 104" fill="none" stroke="${IN}" stroke-width="2" opacity=".35"/><ellipse cx="46" cy="116" rx="13" ry="19" fill="#fff" ${SW}/><ellipse cx="154" cy="116" rx="13" ry="19" fill="#fff" ${SW}/><ellipse cx="46" cy="116" rx="6" ry="11" fill="#ffb8d2"/><ellipse cx="154" cy="116" rx="6" ry="11" fill="#ffb8d2"/>`;
    const armL = `<path d="M64 160 Q36 150 28 112" fill="none" stroke="${IN}" stroke-width="27" stroke-linecap="round"/><path d="M64 160 Q36 150 28 112" fill="none" stroke="${o.top}" stroke-width="21" stroke-linecap="round"/><circle cx="26" cy="104" r="12" fill="${o.skin}" ${SW}/>`;
    const armR = `<path d="M136 160 Q164 150 172 112" fill="none" stroke="${IN}" stroke-width="27" stroke-linecap="round"/><path d="M136 160 Q164 150 172 112" fill="none" stroke="${o.top}" stroke-width="21" stroke-linecap="round"/><circle cx="174" cy="104" r="12" fill="${o.skin}" ${SW}/>`;
    const armRfist = `<path d="M136 164 Q160 176 150 200" fill="none" stroke="${IN}" stroke-width="27" stroke-linecap="round"/><path d="M136 164 Q160 176 150 200" fill="none" stroke="${o.top}" stroke-width="21" stroke-linecap="round"/><circle cx="150" cy="206" r="12" fill="${o.skin}" ${SW}/>`;
    if (k === 'pink') arms = armL + armR;
    else if (k === 'brown') arms = armL + armR;
    else arms = armL.replace(/28 112/, '26 196').replace('36 150', '34 180').replace('cy="104"', 'cy="198"').replace('cx="26"', 'cx="24"') + armRfist;
    const skirt = k === 'boy' ? `<path d="M62 232 L138 232 L142 256 H58Z" fill="${o.bottom}" ${SW}/>` : `<path d="M60 228 L140 228 L150 262 H50Z" fill="${o.bottom}" ${SW}/>`;
    const sock = k !== 'boy' ? `<path d="M66 262 L64 280 H92 L94 262Z M134 262 L136 280 H108 L106 262Z" fill="#3a3550" opacity=".85"/>` : '';
    const cat = k === 'pink' ? '#fff' : k === 'brown' ? '#fff' : '#bdbfd0';
    const parts = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 300" class="chibi chibi-${k}">${back}${legs}${sock}${hoodie(cat)}${skirt}${arms}${head}${face()}${front}${extra}</svg>`;
    return parts;
  }

  /* ================= MENÜ HÁTTÉR ================= */
  function menuBg() {
    let city = '';
    const r = rng(42);
    [['#b9c6ff', 0.55, 300, 90], ['#9fa8f0', 0.75, 380, 120], ['#8791dd', 0.95, 450, 170]].forEach(([c, op, base, hmax], layer) => {
      let x = 330 + layer * 12;
      while (x < 1260) {
        const wd = 46 + r() * 56, h = 60 + r() * hmax;
        city += `<rect x="${x}" y="${640 - h - 10}" width="${wd}" height="${h + 20}" fill="${c}" opacity="${op}" rx="3"/>`;
        if (layer > 0) for (let yy = 640 - h + 4; yy < 626; yy += 22) for (let xx = x + 8; xx < x + wd - 12; xx += 18) if (r() > 0.4) city += `<rect x="${xx}" y="${yy}" width="9" height="12" rx="2" fill="${r() > 0.5 ? '#fff6c0' : '#d7e7ff'}" opacity=".9"/>`;
        x += wd + 4;
      }
    });
    const tinyCat = (x, y, c, s = 1) => `<g transform="translate(${x} ${y}) scale(${s})"><path d="M-20 24 Q-22 -6 0 -6 Q22 -6 20 24Z" fill="${c}" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><path d="M-18 4 L-18 -18 L-4 -8Z M18 4 L18 -18 L4 -8Z" fill="${c}" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/><circle cx="-7" cy="8" r="2.4" fill="${IN}"/><circle cx="7" cy="8" r="2.4" fill="${IN}"/><path d="M-3 13 Q0 16 3 13" stroke="${IN}" stroke-width="2" fill="none" stroke-linecap="round"/><ellipse cx="-12" cy="14" rx="4" ry="2.6" fill="#ff9ab8" opacity=".6"/><ellipse cx="12" cy="14" rx="4" ry="2.6" fill="#ff9ab8" opacity=".6"/></g>`;
    const pot = (x, y, c) => `<path d="M${x - 24} ${y} H${x + 24} L${x + 18} ${y + 36} H${x - 18}Z" fill="${c}" stroke="${IN}" stroke-width="3" stroke-linejoin="round"/>`;
    const plant = (x, y, s) => `<g transform="translate(${x} ${y}) scale(${s})" stroke="${IN}" stroke-width="3" stroke-linejoin="round" fill="#7fd48e"><path d="M0 0 Q-34 -20 -40 -60 Q-6 -50 0 0Z"/><path d="M0 0 Q34 -24 44 -64 Q8 -54 0 0Z"/><path d="M0 0 Q-8 -30 0 -80 Q12 -30 0 0Z" fill="#5fc37a"/></g>`;
    return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" class="bgsvg"><defs>
<linearGradient id="mbw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f6d6ee"/><stop offset="1" stop-color="#fbe3df"/></linearGradient>
<linearGradient id="mbs" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fc2ff"/><stop offset=".6" stop-color="#bcd4ff"/><stop offset="1" stop-color="#ffd3e6"/></linearGradient>
<linearGradient id="mbf" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4cdc8"/><stop offset="1" stop-color="#ebb6c0"/></linearGradient>
<clipPath id="mbwin"><path d="M400 640 V240 Q400 70 650 70 H980 Q1230 70 1230 240 V640Z"/></clipPath></defs>
<rect width="1600" height="900" fill="url(#mbw)"/>
<g fill="#fff" opacity=".35">${Array.from({ length: 16 }, (_, i) => `<circle cx="${(i * 197) % 1600}" cy="${(i * 131) % 700}" r="${6 + (i % 4) * 4}"/>`).join('')}</g>
<g clip-path="url(#mbwin)"><rect x="380" y="60" width="870" height="600" fill="url(#mbs)"/>
<g class="cloud-a"><g fill="#fff" opacity=".9"><circle cx="560" cy="200" r="30"/><circle cx="600" cy="186" r="40"/><circle cx="650" cy="204" r="30"/><rect x="530" y="200" width="150" height="34" rx="17"/></g></g>
<g class="cloud-b"><g fill="#fff" opacity=".85"><circle cx="1010" cy="260" r="26"/><circle cx="1046" cy="246" r="36"/><circle cx="1092" cy="262" r="26"/><rect x="984" y="260" width="140" height="30" rx="15"/></g></g>
${city}</g>
<path d="M400 640 V240 Q400 70 650 70 H980 Q1230 70 1230 240 V640Z" fill="none" stroke="#fff" stroke-width="18" stroke-linejoin="round"/>
<path d="M400 640 V240 Q400 70 650 70 H980 Q1230 70 1230 240 V640Z" fill="none" stroke="${IN}" stroke-width="3" opacity=".35"/>
<path d="M815 70 V640 M400 360 H1230" stroke="#fff" stroke-width="12"/>
<rect x="388" y="636" width="854" height="22" rx="8" fill="#fff"/>
<g class="sunrot" style="transform-origin:480px 170px">${Array.from({ length: 12 }, (_, i) => `<path d="M480 118 L486 98 L474 98Z" fill="#fff3a0" transform="rotate(${i * 30} 480 170)"/>`).join('')}</g>
<g class="sunbob"><circle cx="480" cy="170" r="52" fill="#fff0a0" stroke="#ffe27a" stroke-width="5"/><circle cx="478" cy="164" r="42" fill="#fff6c0"/><circle cx="464" cy="160" r="4.4" fill="${IN}"/><circle cx="494" cy="160" r="4.4" fill="${IN}"/><path d="M468 176 Q479 188 490 176" stroke="${IN}" stroke-width="3.4" fill="none" stroke-linecap="round"/><ellipse cx="454" cy="176" rx="8" ry="5" fill="#ff9ab8" opacity=".6"/><ellipse cx="504" cy="176" rx="8" ry="5" fill="#ff9ab8" opacity=".6"/></g>
<!-- bal polc -->
<rect x="-20" y="300" width="360" height="22" rx="8" fill="#e9c4a4" stroke="${IN}" stroke-width="3"/><rect x="-20" y="520" width="330" height="22" rx="8" fill="#e9c4a4" stroke="${IN}" stroke-width="3"/>
${pot(70, 262, '#ff9ccf')}${plant(70, 262, 1.3)}${pot(250, 270, '#9ed2ff')}${plant(250, 270, 1)}${tinyCat(170, 290, '#fff', 1)}
${pot(60, 490, '#ffe27a')}${plant(60, 490, 1.1)}${tinyCat(200, 520, '#ffd9a8', 1.1)}${tinyCat(270, 524, '#c9b6ff', 0.9)}
<g stroke="${IN}" stroke-width="3" stroke-linecap="round" fill="none"><path d="M150 0 V70 M290 0 V40 M30 0 V90" stroke-width="3"/></g>
<g stroke="${IN}" stroke-width="3" stroke-linejoin="round">${[[150, 80], [150, 130], [160, 180], [290, 52], [292, 96], [30, 100], [34, 150]].map(([x, y], i) => `<path d="M${x} ${y} q-24 -6 -30 16 q22 12 30 -16z" fill="${i % 2 ? '#7fd48e' : '#5fc37a'}"/><path d="M${x} ${y} q24 -6 30 16 q-22 12 -30 -16z" fill="${i % 2 ? '#5fc37a' : '#7fd48e'}"/>`).join('')}</g>
<!-- jobb polc -->
<rect x="1330" y="310" width="300" height="22" rx="8" fill="#e9c4a4" stroke="${IN}" stroke-width="3"/><rect x="1300" y="560" width="330" height="22" rx="8" fill="#e9c4a4" stroke="${IN}" stroke-width="3"/>
${tinyCat(1400, 300, '#fff', 1)}${tinyCat(1480, 304, '#ffcf9f', 0.9)}${tinyCat(1560, 300, '#e6e0f5', 1.1)}${pot(1520, 262, '#c9b6ff')}
${tinyCat(1350, 550, '#bdbfd0', 1)}${tinyCat(1440, 556, '#fff', 0.9)}
<!-- padló -->
<rect x="0" y="720" width="1600" height="180" fill="url(#mbf)"/><path d="M0 720 H1600" stroke="${IN}" stroke-width="3" opacity=".25"/>
<g opacity=".25" stroke="#fff" stroke-width="4">${Array.from({ length: 9 }, (_, i) => `<path d="M${i * 200 - 40} 720 L${i * 240 - 200} 900"/>`).join('')}</g>
<g><ellipse cx="420" cy="860" rx="330" ry="86" fill="#ffd0e3" stroke="${IN}" stroke-width="4"/><path d="M200 800 L190 740 L260 780Z M640 800 L650 740 L580 780Z" fill="#ffd0e3" stroke="${IN}" stroke-width="4" stroke-linejoin="round"/><ellipse cx="330" cy="850" rx="16" ry="9" fill="${IN}" opacity=".5"/><ellipse cx="510" cy="850" rx="16" ry="9" fill="${IN}" opacity=".5"/><path d="M395 872 Q420 888 445 872" stroke="${IN}" stroke-width="5" fill="none" stroke-linecap="round" opacity=".5"/></g>
<ellipse cx="1280" cy="840" rx="190" ry="54" fill="#c9b6ff" stroke="${IN}" stroke-width="4"/><ellipse cx="1280" cy="826" rx="140" ry="30" fill="#dcccff"/>
</svg>`;
  }

  w.Art = { PAL, col, mix, lighten, darken, rng, starPath, heartPath, cardArt, catOnly, mascot, packSVG, cardBack, icon, chibi, menuBg, IN };
})(window);
